class OrderModel {
  final String? id; 
  final String service;
  final String alamat;
  final String metode;
  final String status;
  final String tanggal;

  OrderModel({
    this.id,
    required this.service,
    required this.alamat,
    required this.metode,
    required this.status,
    required this.tanggal,
  });

  factory OrderModel.fromMap(Map<String, dynamic> map) {
    return OrderModel(
      id: map['id']?.toString(), 
      service: map['service'] ?? '',
      alamat: map['alamat'] ?? '',
      metode: map['metode'] ?? '',
      status: map['status'] ?? '',
      tanggal: map['tanggal'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    
    return {
      'service': service,
      'alamat': alamat,
      'metode': metode,
      'status': status,
      'tanggal': tanggal,
    };
  }
}

