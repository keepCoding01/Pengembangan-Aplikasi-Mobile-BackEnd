// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

class AppLocalizationsId extends AppLocalizations {
  AppLocalizationsId([String locale = 'id']) : super(locale);

  @override
  String get appTitle => 'Moro App';

  @override
  String get orders => 'Pesanan';

  @override
  String get settings => 'Pengaturan';

  @override
  String get language => 'Bahasa';

  @override
  String get logout => 'Keluar';

  @override
  String get welcome => 'Selamat Datang';

  @override
  String get notification => 'Notifikasi';

  @override
  String get darkMode => 'Mode Gelap';

  @override
  String helloUser(String name) {
    return 'Halo, $name 👋';
  }

  @override
  String get specialPromo => 'Promo Spesial!';

  @override
  String get discountPromo => 'Diskon hingga 30%';

  @override
  String get newService => 'Layanan Baru';

  @override
  String get promoService => 'Layanan promosi';

  @override
  String get serviceAdded => 'Layanan berhasil ditambahkan';

  @override
  String get myOrders => 'Pesanan Saya';

  @override
  String get noOrders => 'Belum ada pesanan';

  @override
  String get loadOrderFailed => 'Gagal memuat pesanan';

  @override
  String get address => 'Alamat';

  @override
  String get status => 'Status';

  @override
  String get orderDetail => 'Detail Pesanan';

  @override
  String get changeStatus => 'Ubah Status';

  @override
  String get email => 'Email';

  @override
  String get aboutApp => 'Tentang Aplikasi';

  @override
  String get createOrder => 'Pesan Layanan';

  @override
  String get service => 'Layanan';

  @override
  String get cleaning => 'Bersih-bersih';

  @override
  String get laundry => 'Laundry';

  @override
  String get repair => 'Perbaikan';

  @override
  String get addressHint => 'Masukkan alamat';

  @override
  String get paymentMethod => 'Metode Pembayaran';

  @override
  String get cash => 'Tunai';

  @override
  String get transfer => 'Transfer';

  @override
  String get submitOrder => 'Kirim Pesanan';

  @override
  String get orderSuccess => 'Pesanan berhasil dibuat';

  @override
  String get orderFailed => 'Pesanan gagal dibuat';

  @override
  String get aboutTitle => 'Tentang Kami';

  @override
  String get appDescriptionTitle => 'Aplikasi Layanan Kebersihan Moro App';

  @override
  String get appDescription => 'Moro App adalah solusi praktis untuk kebutuhan kebersihan rumah tangga dan kantor Anda. Kami berkomitmen untuk menyediakan layanan terbaik dengan tenaga kerja yang profesional.';

  @override
  String get teamListTitle => 'Daftar Anggota Tim (Dapat Diedit dan Disimpan)';

  @override
  String get addMember => 'Tambah Anggota Baru';

  @override
  String get editMember => 'Edit Nama Anggota';

  @override
  String get deleteMember => 'Hapus';

  @override
  String get cancel => 'Batal';

  @override
  String get save => 'Simpan';

  @override
  String get memberDeleted => 'Anggota berhasil dihapus.';

  @override
  String get enterName => 'Masukkan nama';

  @override
  String get basicCleaningTitle => 'Pembersihan Dasar';

  @override
  String get basicCleaningDesc => 'Pembersihan ringan';

  @override
  String get deepCleaningTitle => 'Pembersihan Mendalam';

  @override
  String get deepCleaningDesc => 'Pembersihan menyeluruh';

  @override
  String get statusPending => 'Menunggu';

  @override
  String get accessDenied => 'Akses ditolak (bukan admin)';

  @override
  String get add => 'Tambah';

  @override
  String get statusDone => 'Selesai';

  @override
  String get admin => 'Admin';

  @override
  String get user => 'Pengguna';

  @override
  String get defaultUser => 'Pengguna';
}
