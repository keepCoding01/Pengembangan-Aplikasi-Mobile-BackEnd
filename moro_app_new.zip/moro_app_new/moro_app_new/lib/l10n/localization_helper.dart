import 'app_localizations.dart';

extension AppLocalizationsExtension on AppLocalizations {

  String? getString(String key) {
    switch (key) {
      case "appTitle": return appTitle;
      case "orders": return orders;
      case "settings": return settings;
      case "language": return language;
      case "logout": return logout;
      case "welcome": return welcome;
      case "notification": return notification;
      case "darkMode": return darkMode;
      case "helloUser": return helloUser(""); 
      case "specialPromo": return specialPromo;
      case "discountPromo": return discountPromo;
      case "newService": return newService;
      case "promoService": return promoService;
      case "serviceAdded": return serviceAdded;
      case "myOrders": return myOrders;
      case "noOrders": return noOrders;
      case "loadOrderFailed": return loadOrderFailed;
      case "address": return address;
      case "status": return status;
      case "orderDetail": return orderDetail;
      case "changeStatus": return changeStatus;
      case "email": return email;
      case "aboutApp": return aboutApp;
      case "createOrder": return createOrder;
      case "service": return service;
      case "cleaning": return cleaning;
      case "laundry": return laundry;
      case "repair": return repair;
      case "addressHint": return addressHint;
      case "paymentMethod": return paymentMethod;
      case "cash": return cash;
      case "transfer": return transfer;
      case "submitOrder": return submitOrder;
      case "orderSuccess": return orderSuccess;
      case "orderFailed": return orderFailed;
      case "aboutTitle": return aboutTitle;
      case "appDescriptionTitle": return appDescriptionTitle;
      case "appDescription": return appDescription;
      case "teamListTitle": return teamListTitle;
      case "addMember": return addMember;
      case "editMember": return editMember;
      case "deleteMember": return deleteMember;
      case "cancel": return cancel;
      case "save": return save;
      case "memberDeleted": return memberDeleted;
      case "enterName": return enterName;
      case "basicCleaningTitle": return basicCleaningTitle;
      case "basicCleaningDesc": return basicCleaningDesc;
      case "deepCleaningTitle": return deepCleaningTitle;
      case "deepCleaningDesc": return deepCleaningDesc;
      case "statusPending": return statusPending;
      case "accessDenied": return accessDenied;
      case "add": return add;
      default: return key;
    }
  }
}
