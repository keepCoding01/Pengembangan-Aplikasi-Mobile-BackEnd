import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_de.dart';
import 'app_localizations_en.dart';
import 'app_localizations_id.dart';
import 'app_localizations_zh.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('de'),
    Locale('en'),
    Locale('id'),
    Locale('zh')
  ];

  /// Application title
  ///
  /// In en, this message translates to:
  /// **'Moro App'**
  String get appTitle;

  /// Orders page
  ///
  /// In en, this message translates to:
  /// **'Orders'**
  String get orders;

  /// Settings page
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settings;

  /// Language setting
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get language;

  /// Logout button
  ///
  /// In en, this message translates to:
  /// **'Logout'**
  String get logout;

  /// Welcome text
  ///
  /// In en, this message translates to:
  /// **'Welcome'**
  String get welcome;

  /// Notification setting
  ///
  /// In en, this message translates to:
  /// **'Notification'**
  String get notification;

  /// Dark mode toggle
  ///
  /// In en, this message translates to:
  /// **'Dark Mode'**
  String get darkMode;

  /// Greet user with their name
  ///
  /// In en, this message translates to:
  /// **'Hello, {name} 👋'**
  String helloUser(String name);

  /// Special promo text
  ///
  /// In en, this message translates to:
  /// **'Special Promo!'**
  String get specialPromo;

  /// Discount promo text
  ///
  /// In en, this message translates to:
  /// **'Up to 30% discount'**
  String get discountPromo;

  /// New service text
  ///
  /// In en, this message translates to:
  /// **'New Service'**
  String get newService;

  /// Promotional service text
  ///
  /// In en, this message translates to:
  /// **'Promotional service'**
  String get promoService;

  /// Message when service added successfully
  ///
  /// In en, this message translates to:
  /// **'Service successfully added'**
  String get serviceAdded;

  /// My Orders page title
  ///
  /// In en, this message translates to:
  /// **'My Orders'**
  String get myOrders;

  /// Text shown when there are no orders
  ///
  /// In en, this message translates to:
  /// **'No orders yet'**
  String get noOrders;

  /// Text shown when loading orders fails
  ///
  /// In en, this message translates to:
  /// **'Failed to load orders'**
  String get loadOrderFailed;

  /// Address label
  ///
  /// In en, this message translates to:
  /// **'Address'**
  String get address;

  /// Order status label
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get status;

  /// Order detail page title
  ///
  /// In en, this message translates to:
  /// **'Order Detail'**
  String get orderDetail;

  /// Button to change order status
  ///
  /// In en, this message translates to:
  /// **'Change Status'**
  String get changeStatus;

  /// Email label
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get email;

  /// About App menu
  ///
  /// In en, this message translates to:
  /// **'About App'**
  String get aboutApp;

  /// Button to create a new order
  ///
  /// In en, this message translates to:
  /// **'Create Order'**
  String get createOrder;

  /// Service label
  ///
  /// In en, this message translates to:
  /// **'Service'**
  String get service;

  /// Service type: cleaning
  ///
  /// In en, this message translates to:
  /// **'Cleaning'**
  String get cleaning;

  /// Service type: laundry
  ///
  /// In en, this message translates to:
  /// **'Laundry'**
  String get laundry;

  /// Service type: repair
  ///
  /// In en, this message translates to:
  /// **'Repair'**
  String get repair;

  /// Address input placeholder
  ///
  /// In en, this message translates to:
  /// **'Enter address'**
  String get addressHint;

  /// Payment method label
  ///
  /// In en, this message translates to:
  /// **'Payment Method'**
  String get paymentMethod;

  /// Payment method: cash
  ///
  /// In en, this message translates to:
  /// **'Cash'**
  String get cash;

  /// Payment method: bank transfer
  ///
  /// In en, this message translates to:
  /// **'Bank Transfer'**
  String get transfer;

  /// Button to submit an order
  ///
  /// In en, this message translates to:
  /// **'Submit Order'**
  String get submitOrder;

  /// Message when order created successfully
  ///
  /// In en, this message translates to:
  /// **'Order created successfully'**
  String get orderSuccess;

  /// Message when order creation fails
  ///
  /// In en, this message translates to:
  /// **'Failed to create order'**
  String get orderFailed;

  /// About Us page title
  ///
  /// In en, this message translates to:
  /// **'About Us'**
  String get aboutTitle;

  /// App description title
  ///
  /// In en, this message translates to:
  /// **'Moro App Cleaning Services'**
  String get appDescriptionTitle;

  /// Application description
  ///
  /// In en, this message translates to:
  /// **'Moro App is a practical solution for your home and office cleaning needs. We are committed to providing the best services with professional staff.'**
  String get appDescription;

  /// Title for team members list
  ///
  /// In en, this message translates to:
  /// **'Team Members List (Editable and Savable)'**
  String get teamListTitle;

  /// Button to add a new member
  ///
  /// In en, this message translates to:
  /// **'Add New Member'**
  String get addMember;

  /// Button to edit member name
  ///
  /// In en, this message translates to:
  /// **'Edit Member Name'**
  String get editMember;

  /// Button to delete a member
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get deleteMember;

  /// Cancel button
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// Save button
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get save;

  /// Message shown when a member is deleted
  ///
  /// In en, this message translates to:
  /// **'Member successfully deleted.'**
  String get memberDeleted;

  /// Placeholder for member name input
  ///
  /// In en, this message translates to:
  /// **'Enter name'**
  String get enterName;

  /// Title for basic cleaning service
  ///
  /// In en, this message translates to:
  /// **'Basic Cleaning'**
  String get basicCleaningTitle;

  /// Description for basic cleaning service
  ///
  /// In en, this message translates to:
  /// **'Light cleaning'**
  String get basicCleaningDesc;

  /// Title for deep cleaning service
  ///
  /// In en, this message translates to:
  /// **'Deep Cleaning'**
  String get deepCleaningTitle;

  /// Description for deep cleaning service
  ///
  /// In en, this message translates to:
  /// **'Thorough cleaning'**
  String get deepCleaningDesc;

  /// Order status pending
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get statusPending;

  /// Message when non-admin tries admin access
  ///
  /// In en, this message translates to:
  /// **'Access denied (not admin)'**
  String get accessDenied;

  /// Button text for adding a new member
  ///
  /// In en, this message translates to:
  /// **'Add'**
  String get add;

  /// Order status done
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get statusDone;

  /// Label role admin
  ///
  /// In en, this message translates to:
  /// **'Admin'**
  String get admin;

  /// Label role user
  ///
  /// In en, this message translates to:
  /// **'User'**
  String get user;

  /// Fallback text if user name is empty
  ///
  /// In en, this message translates to:
  /// **'User'**
  String get defaultUser;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['de', 'en', 'id', 'zh'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'de': return AppLocalizationsDe();
    case 'en': return AppLocalizationsEn();
    case 'id': return AppLocalizationsId();
    case 'zh': return AppLocalizationsZh();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
