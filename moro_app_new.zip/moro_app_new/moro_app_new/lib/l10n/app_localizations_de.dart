// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

class AppLocalizationsDe extends AppLocalizations {
  AppLocalizationsDe([String locale = 'de']) : super(locale);

  @override
  String get appTitle => 'Moro App';

  @override
  String get orders => 'Bestellungen';

  @override
  String get settings => 'Einstellungen';

  @override
  String get language => 'Sprache';

  @override
  String get logout => 'Abmelden';

  @override
  String get welcome => 'Willkommen';

  @override
  String get notification => 'Benachrichtigung';

  @override
  String get darkMode => 'Dunkler Modus';

  @override
  String helloUser(String name) {
    return 'Hallo, $name 👋';
  }

  @override
  String get specialPromo => 'Sonderangebot!';

  @override
  String get discountPromo => 'Bis zu 30% Rabatt';

  @override
  String get newService => 'Neuer Service';

  @override
  String get promoService => 'Werbeservice';

  @override
  String get serviceAdded => 'Service erfolgreich hinzugefügt';

  @override
  String get myOrders => 'Meine Bestellungen';

  @override
  String get noOrders => 'Noch keine Bestellungen';

  @override
  String get loadOrderFailed => 'Bestellungen konnten nicht geladen werden';

  @override
  String get address => 'Adresse';

  @override
  String get status => 'Status';

  @override
  String get orderDetail => 'Bestelldetails';

  @override
  String get changeStatus => 'Status ändern';

  @override
  String get email => 'E-Mail';

  @override
  String get aboutApp => 'Über die App';

  @override
  String get createOrder => 'Bestellung erstellen';

  @override
  String get service => 'Dienstleistung';

  @override
  String get cleaning => 'Reinigung';

  @override
  String get laundry => 'Wäscherei';

  @override
  String get repair => 'Reparatur';

  @override
  String get addressHint => 'Adresse eingeben';

  @override
  String get paymentMethod => 'Zahlungsmethode';

  @override
  String get cash => 'Barzahlung';

  @override
  String get transfer => 'Überweisung';

  @override
  String get submitOrder => 'Bestellung senden';

  @override
  String get orderSuccess => 'Bestellung erfolgreich erstellt';

  @override
  String get orderFailed => 'Bestellung fehlgeschlagen';

  @override
  String get aboutTitle => 'Über Uns';

  @override
  String get appDescriptionTitle => 'Moro App Reinigungsdienste';

  @override
  String get appDescription => 'Moro App ist eine praktische Lösung für Ihre Reinigungsbedürfnisse zu Hause und im Büro. Wir verpflichten uns, den besten Service mit professionellem Personal anzubieten.';

  @override
  String get teamListTitle => 'Teammitgliederliste (Bearbeitbar und Speichbar)';

  @override
  String get addMember => 'Neues Mitglied hinzufügen';

  @override
  String get editMember => 'Mitgliedsname bearbeiten';

  @override
  String get deleteMember => 'Löschen';

  @override
  String get cancel => 'Abbrechen';

  @override
  String get save => 'Speichern';

  @override
  String get memberDeleted => 'Mitglied erfolgreich gelöscht.';

  @override
  String get enterName => 'Name eingeben';

  @override
  String get basicCleaningTitle => 'Grundreinigung';

  @override
  String get basicCleaningDesc => 'Leichte Reinigung';

  @override
  String get deepCleaningTitle => 'Tiefenreinigung';

  @override
  String get deepCleaningDesc => 'Gründliche Reinigung';

  @override
  String get statusPending => 'Ausstehend';

  @override
  String get accessDenied => 'Zugriff verweigert (kein Admin)';

  @override
  String get add => 'Hinzufügen';

  @override
  String get statusDone => 'Abgeschlossen';

  @override
  String get admin => 'Admin';

  @override
  String get user => 'Benutzer';

  @override
  String get defaultUser => 'Benutzer';
}
