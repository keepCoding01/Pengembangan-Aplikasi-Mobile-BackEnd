// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Moro App';

  @override
  String get orders => 'Orders';

  @override
  String get settings => 'Settings';

  @override
  String get language => 'Language';

  @override
  String get logout => 'Logout';

  @override
  String get welcome => 'Welcome';

  @override
  String get notification => 'Notification';

  @override
  String get darkMode => 'Dark Mode';

  @override
  String helloUser(String name) {
    return 'Hello, $name 👋';
  }

  @override
  String get specialPromo => 'Special Promo!';

  @override
  String get discountPromo => 'Up to 30% discount';

  @override
  String get newService => 'New Service';

  @override
  String get promoService => 'Promotional service';

  @override
  String get serviceAdded => 'Service successfully added';

  @override
  String get myOrders => 'My Orders';

  @override
  String get noOrders => 'No orders yet';

  @override
  String get loadOrderFailed => 'Failed to load orders';

  @override
  String get address => 'Address';

  @override
  String get status => 'Status';

  @override
  String get orderDetail => 'Order Detail';

  @override
  String get changeStatus => 'Change Status';

  @override
  String get email => 'Email';

  @override
  String get aboutApp => 'About App';

  @override
  String get createOrder => 'Create Order';

  @override
  String get service => 'Service';

  @override
  String get cleaning => 'Cleaning';

  @override
  String get laundry => 'Laundry';

  @override
  String get repair => 'Repair';

  @override
  String get addressHint => 'Enter address';

  @override
  String get paymentMethod => 'Payment Method';

  @override
  String get cash => 'Cash';

  @override
  String get transfer => 'Bank Transfer';

  @override
  String get submitOrder => 'Submit Order';

  @override
  String get orderSuccess => 'Order created successfully';

  @override
  String get orderFailed => 'Failed to create order';

  @override
  String get aboutTitle => 'About Us';

  @override
  String get appDescriptionTitle => 'Moro App Cleaning Services';

  @override
  String get appDescription => 'Moro App is a practical solution for your home and office cleaning needs. We are committed to providing the best services with professional staff.';

  @override
  String get teamListTitle => 'Team Members List (Editable and Savable)';

  @override
  String get addMember => 'Add New Member';

  @override
  String get editMember => 'Edit Member Name';

  @override
  String get deleteMember => 'Delete';

  @override
  String get cancel => 'Cancel';

  @override
  String get save => 'Save';

  @override
  String get memberDeleted => 'Member successfully deleted.';

  @override
  String get enterName => 'Enter name';

  @override
  String get basicCleaningTitle => 'Basic Cleaning';

  @override
  String get basicCleaningDesc => 'Light cleaning';

  @override
  String get deepCleaningTitle => 'Deep Cleaning';

  @override
  String get deepCleaningDesc => 'Thorough cleaning';

  @override
  String get statusPending => 'Pending';

  @override
  String get accessDenied => 'Access denied (not admin)';

  @override
  String get add => 'Add';

  @override
  String get statusDone => 'Done';

  @override
  String get admin => 'Admin';

  @override
  String get user => 'User';

  @override
  String get defaultUser => 'User';
}
