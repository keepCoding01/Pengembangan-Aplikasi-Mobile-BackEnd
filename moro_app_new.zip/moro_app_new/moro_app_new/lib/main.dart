import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'theme/theme_provider.dart';
import 'pages/login_page.dart';
import 'pages/main_page.dart';
import 'theme/app_theme.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'localization/locale_provider.dart';
import 'l10n/app_localizations.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  await ThemeProvider.loadTheme();
  await LocaleProvider.loadLocale();

  final prefs = await SharedPreferences.getInstance();
  final isLoggedIn = prefs.getBool('isLoggedIn') ?? false;

  runApp(MoroApp(isLoggedIn: isLoggedIn));
}

class MoroApp extends StatefulWidget {
  final bool isLoggedIn;
  const MoroApp({super.key, required this.isLoggedIn});

  @override
  State<MoroApp> createState() => _MoroAppState();
}

class _MoroAppState extends State<MoroApp> {
  @override
  void initState() {
    super.initState();

    ThemeProvider.themeStream.listen((_) {
      if (mounted) setState(() {});
    });

    LocaleProvider.localeStream.listen((_) {
      if (mounted) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Moro',

      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeProvider.currentMode,

      locale: LocaleProvider.currentLocale,

      supportedLocales: const [
        Locale('id'),
        Locale('en'),
        Locale('de'),
        Locale('zh'),
      ],

      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],

      home: widget.isLoggedIn ? const MainPage() : const LoginPage(),
    );
  }
}
