import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LocaleProvider {
  static const _key = 'app_locale';

  static Locale _locale = const Locale('id');
  static final _controller = StreamController<Locale>.broadcast();

  static Stream<Locale> get localeStream => _controller.stream;
  static Locale get currentLocale => _locale;

  static Future<void> loadLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final code = prefs.getString(_key) ?? 'id';
    _locale = Locale(code);
    _controller.add(_locale);
  }

  static Future<void> setLocale(String code) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, code);
    _locale = Locale(code);
    _controller.add(_locale);
  }
}
