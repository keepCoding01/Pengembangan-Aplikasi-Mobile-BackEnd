import 'dart:async';

class OrderStatusStream {
  static Stream<Map<String, dynamic>> trackStatus() async* {
    List<String> steps = [
      "Menunggu",
      "Diproses",
      "Pekerja Menuju Lokasi",
      "Sedang Dikerjakan",
      "Selesai",
    ];

    for (int i = 0; i < steps.length; i++) {
      yield {"index": i, "status": steps[i]};
      await Future.delayed(const Duration(seconds: 3));
    }
  }
}
