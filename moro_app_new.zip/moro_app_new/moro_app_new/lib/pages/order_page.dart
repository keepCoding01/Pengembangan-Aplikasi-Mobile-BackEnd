import 'package:flutter/material.dart';
import '../api/api_service.dart';
import '../l10n/app_localizations.dart';

class OrderPage extends StatefulWidget {
  final String serviceName;
  const OrderPage({super.key,required this.serviceName});

  @override
  State<OrderPage> createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  final _alamatController = TextEditingController();

  late String _service;

  String _metode = "Cash";
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _service = widget.serviceName;
  }

  @override
  void dispose() {
    _alamatController.dispose();
    super.dispose();
  }

  Future<void> _submitOrder() async {
    if (_alamatController.text.isEmpty) return;

    setState(() => _loading = true);

    final success = await ApiService.createOrder(
      _service,
      _alamatController.text,
      _metode,
    );

    if (!mounted) return;

    setState(() => _loading = false);

    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppLocalizations.of(context)!.orderSuccess)),
      );
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppLocalizations.of(context)!.orderFailed)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: Colors.pink[50],
      appBar: AppBar(
        title: Text(t.createOrder),
        backgroundColor: Colors.pink,
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(t.service, style: _title()),
                const SizedBox(height: 8),
                Text(
                  _service,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.pink,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(t.address, style: _title()),
                const SizedBox(height: 8),
                TextField(
                  controller: _alamatController,
                  decoration: _inputDecoration(
                    hint: t.addressHint,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(t.paymentMethod, style: _title()),
                const SizedBox(height: 8),
                DropdownButtonFormField(
                  value: _metode,
                  items: [
                    DropdownMenuItem(
                      value: "Cash",
                      child: Text(t.cash),
                    ),
                    DropdownMenuItem(
                      value: "Transfer",
                      child: Text(t.transfer),
                    ),
                  ],
                  onChanged: (v) => setState(() => _metode = v!),
                  decoration: _inputDecoration(),
                ),
              ],
            ),
          ),

          const SizedBox(height: 30),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _loading ? null : _submitOrder,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: _loading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : Text(
                      t.submitOrder,
                      style: const TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 6,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }

  TextStyle _title() {
    return const TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 16,
      color: Colors.pink,
    );
  }

  InputDecoration _inputDecoration({String? hint}) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: Colors.grey[100],
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    );
  }
}
