import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:geolocator/geolocator.dart';

import '../api/api_service.dart';
import '../l10n/app_localizations.dart';
import 'login_page.dart';
import 'settings_page.dart';
import 'about_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String _email = "User Moro";
  String _role = "user";
  bool _loading = true;
  File? _profileImage;
  String? _profileImageWebPath;
  String? _pickedFileName;
  String? _location;

  final ImagePicker _picker = ImagePicker();

  final FirebaseStorage _storage = FirebaseStorage.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final user = _auth.currentUser;

      if (!mounted) return;

      setState(() {
        _email = user?.email ?? "User Moro";
        _role = prefs.getString('userRole') ?? 'user';
        _loading = false;
      });

      if (user != null) {
        final doc = await _firestore.collection('users').doc(user.uid).get();
        if (doc.exists) {
          final data = doc.data();
          setState(() {
            _profileImageWebPath = data?['photoUrl'];
            _location = data?['location'];
          });
        }
      }
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  /* ===================== IMAGE PICKER & UPLOAD ===================== */
  Future<void> _pickImage() async {
    final XFile? picked = await _picker.pickImage(
      source: ImageSource.camera,
      maxWidth: 600,
      maxHeight: 600,
    );

    if (picked != null) {
      if (kIsWeb) {
        setState(() => _profileImageWebPath = picked.path);
        await _uploadFileWeb(picked);
      } else {
        setState(() => _profileImage = File(picked.path));
        await _uploadFileMobile(File(picked.path), 'profile.jpg');
      }
    }
  }

  /* ===================== FILE PICKER & UPLOAD ===================== */
  Future<void> _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();

    if (result != null) {
      setState(() {
        _pickedFileName = result.files.single.name;
      });

      if (kIsWeb) {
        await _uploadFileWeb(result.files.single);
      } else {
        final file = File(result.files.single.path!);
        await _uploadFileMobile(file, result.files.single.name);
      }
    }
  }

  Future<void> _uploadFileMobile(File file, String fileName) async {
    final user = _auth.currentUser;
    if (user == null) return;

    final ref = _storage.ref('users/${user.uid}/$fileName');
    await ref.putFile(file);
    final url = await ref.getDownloadURL();

    if (fileName == 'profile.jpg') {
      await _firestore.collection('users').doc(user.uid).set({
        'photoUrl': url,
      }, SetOptions(merge: true));
    }
  }

  Future<void> _uploadFileWeb(dynamic file) async {
    final user = _auth.currentUser;
    if (user == null) return;

    final ref = _storage.ref('users/${user.uid}/${file.name}');
    if (file.bytes != null) {
      await ref.putData(file.bytes);
      final url = await ref.getDownloadURL();
      if (file.name == 'profile.jpg') {
        await _firestore.collection('users').doc(user.uid).set({
          'photoUrl': url,
        }, SetOptions(merge: true));
      }
    }
  }

  /* ===================== GEOLOCATION ===================== */
  Future<void> _getLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Location services are disabled.')),
      );
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return;
    }

    if (permission == LocationPermission.deniedForever) return;

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    setState(() {
      _location = '${position.latitude}, ${position.longitude}';
    });

    final user = _auth.currentUser;
    if (user != null) {
      await _firestore.collection('users').doc(user.uid).set({
        'location': _location,
      }, SetOptions(merge: true));
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    if (_loading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(color: Colors.pink),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.pink[50],
      body: Column(
        children: [
          /* ================= HEADER ================= */
          Container(
            width: double.infinity,
            padding: const EdgeInsets.only(top: 40, bottom: 20),
            decoration: const BoxDecoration(
              color: Colors.pink,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(25),
                bottomRight: Radius.circular(25),
              ),
            ),
            child: Column(
              children: [
                Stack(
                  children: [
                    CircleAvatar(
                      radius: 40,
                      backgroundColor: Colors.white,
                      backgroundImage: _profileImage != null
                          ? FileImage(_profileImage!)
                          : (_profileImageWebPath != null
                              ? NetworkImage(_profileImageWebPath!)
                                  as ImageProvider
                              : null),
                      child: (_profileImage == null &&
                              _profileImageWebPath == null)
                          ? const Icon(Icons.person,
                              size: 48, color: Colors.pink)
                          : null,
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: GestureDetector(
                        onTap: _pickImage,
                        child: CircleAvatar(
                          radius: 14,
                          backgroundColor: Colors.white,
                          child: const Icon(Icons.camera_alt,
                              size: 16, color: Colors.pink),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  _email,
                  style: const TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Chip(
                  label: Text(
                    _role.toUpperCase(),
                    style: const TextStyle(color: Colors.white),
                  ),
                  backgroundColor:
                      _role == 'admin' ? Colors.redAccent : Colors.green,
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          /* ================= EMAIL CARD ================= */
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 6,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      const Icon(Icons.email_outlined, color: Colors.pink),
                      const SizedBox(width: 10),
                      Text(
                        t.email,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      _email,
                      style: const TextStyle(color: Colors.grey),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          /* ================= MENU ================= */
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              children: [
                _menuTile(Icons.upload_file, 'Upload Dokumen', _pickFile),
                _menuTile(Icons.location_on, 'Update Lokasi', _getLocation),
                if (_pickedFileName != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text('File dipilih: $_pickedFileName'),
                  ),
                if (_location != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text('Lokasi: $_location'),
                  ),
                _menuTile(Icons.settings, t.settings, () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const SettingsPage(),
                    ),
                  );
                }),
                _menuTile(Icons.info_outline, t.aboutApp, () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AboutPage(),
                    ),
                  );
                }),
              ],
            ),
          ),

          /* ================= LOGOUT ================= */
          Padding(
            padding: const EdgeInsets.all(18),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  await ApiService.logout();

                  if (!mounted) return;

                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const LoginPage(),
                    ),
                    (_) => false,
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text(
                  t.logout,
                  style: const TextStyle(fontSize: 16, color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _menuTile(IconData icon, String title, VoidCallback onTap) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      elevation: 2,
      margin: const EdgeInsets.only(bottom: 14),
      child: ListTile(
        onTap: onTap,
        leading: Icon(icon, color: Colors.pink),
        title: Text(title),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}
