import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../api/api_service.dart';
import '../l10n/app_localizations.dart';

class OrderDetailPage extends StatefulWidget {
  final Map<String, dynamic> order;
  const OrderDetailPage({super.key, required this.order});

  @override
  State<OrderDetailPage> createState() => _OrderDetailPageState();
}

class _OrderDetailPageState extends State<OrderDetailPage> {
  late Map<String, dynamic> order;
  bool _isAdmin = false;
  bool _loading = false;

  File? _imageFile;
  String? _imageWebPath;
  String? _location;

  final ImagePicker _picker = ImagePicker();
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
    order = Map.from(widget.order);
    _checkRole();
    _loadOrderData();
  }

  Future<void> _checkRole() async {
    final admin = await ApiService.isAdmin();
    if (!mounted) return;
    setState(() => _isAdmin = admin);
  }

  Future<void> _loadOrderData() async {
    // Optional: load previously uploaded image & location from Firestore
    final doc = await _firestore.collection('orders').doc(order['id']).get();
    if (doc.exists) {
      final data = doc.data();
      setState(() {
        _imageWebPath = data?['buktiUrl'];
        _location = data?['location'];
      });
    }
  }

  /* ================= UPLOAD BUKTI ORDER ================= */
  Future<void> _pickImage() async {
    final XFile? picked = await _picker.pickImage(
      source: ImageSource.camera,
      maxWidth: 800,
      maxHeight: 800,
    );

    if (picked != null) {
      if (kIsWeb) {
        setState(() => _imageWebPath = picked.path);
        await _uploadFileWeb(picked);
      } else {
        setState(() => _imageFile = File(picked.path));
        await _uploadFileMobile(File(picked.path), 'bukti_order.jpg');
      }
    }
  }

  Future<void> _uploadFileMobile(File file, String fileName) async {
    final ref = _storage.ref('orders/${order['id']}/$fileName');
    await ref.putFile(file);
    final url = await ref.getDownloadURL();
    await _firestore.collection('orders').doc(order['id']).set({
      'buktiUrl': url,
    }, SetOptions(merge: true));
  }

  Future<void> _uploadFileWeb(dynamic file) async {
    final ref = _storage.ref('orders/${order['id']}/${file.name}');
    if (file.bytes != null) {
      await ref.putData(file.bytes);
      final url = await ref.getDownloadURL();
      await _firestore.collection('orders').doc(order['id']).set({
        'buktiUrl': url,
      }, SetOptions(merge: true));
    }
  }

  /* ================= AMBIL LOKASI ================= */
  Future<void> _getLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Location services are disabled.')),
      );
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return;
    }

    if (permission == LocationPermission.deniedForever) return;

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    setState(() {
      _location = '${position.latitude}, ${position.longitude}';
    });

    await _firestore.collection('orders').doc(order['id']).set({
      'location': _location,
    }, SetOptions(merge: true));
  }

  Future<void> _updateStatus() async {
    setState(() => _loading = true);

    final newStatus =
        order['status'] == 'Selesai' ? 'Menunggu' : 'Selesai';

    await ApiService.updateOrderStatus(order['id'], newStatus);

    if (!mounted) return;
    Navigator.pop(context, true);
  }

  Future<void> _delete() async {
    await ApiService.deleteOrder(order['id']);
    if (!mounted) return;
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(t.orderDetail),
        actions: _isAdmin
            ? [
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: _loading ? null : _delete,
                )
              ]
            : [],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              order['service'],
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text("${t.address}: ${order['alamat']}"),
            const SizedBox(height: 6),
            Text("${t.status}: ${order['status']}"),
            const SizedBox(height: 12),

            /* ================= UPLOAD BUKTI ================= */
            Text('Bukti Order:'),
            const SizedBox(height: 6),
            GestureDetector(
              onTap: _pickImage,
              child: Container(
                width: double.infinity,
                height: 180,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.pink),
                ),
                child: _imageFile != null
                    ? Image.file(_imageFile!, fit: BoxFit.cover)
                    : (_imageWebPath != null
                        ? Image.network(_imageWebPath!, fit: BoxFit.cover)
                        : const Center(child: Icon(Icons.camera_alt, size: 40))),
              ),
            ),
            const SizedBox(height: 12),

            /* ================= LOKASI ORDER ================= */
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Lokasi Order: ${_location ?? '-'}'),
                ElevatedButton(
                  onPressed: _getLocation,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.pink,
                  ),
                  child: const Text('Ambil Lokasi'),
                ),
              ],
            ),

            const Spacer(),

            if (_isAdmin)
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _loading ? null : _updateStatus,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.pink,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: Text(
                    t.changeStatus,
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              )
          ],
        ),
      ),
    );
  }
}
