// import 'package:flutter/material.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import '../widgets/service_card.dart';
// import '../widgets/promo_banner.dart';
// import '../api/api_service.dart';
// import 'order_page.dart';
// import 'orders_page.dart';
// import '../l10n/app_localizations.dart';

// class HomePage extends StatefulWidget {
//   const HomePage({super.key});

//   @override
//   State<HomePage> createState() => _HomePageState();
// }

// class _HomePageState extends State<HomePage> {
//   bool _isAdmin = false;
//   String _userName = "User";

//   @override
//   void initState() {
//     super.initState();
//     _loadInitialData();
//   }

//   Future<void> _loadInitialData() async {
//     final admin = await ApiService.isAdmin();
//     final user = FirebaseAuth.instance.currentUser;

//     if (!mounted) return;

//     setState(() {
//       _isAdmin = admin;
//       if (user?.email != null) {
//         final email = user!.email!;
//         _userName = email.split('@').first;
//         _userName =
//             _userName[0].toUpperCase() + _userName.substring(1);
//       }
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     final t = AppLocalizations.of(context)!;

//     return Scaffold(
//       backgroundColor: Colors.white,

//       //  ADMIN ONLY FAB
//       floatingActionButton: _isAdmin
//           ? FloatingActionButton(
//               backgroundColor: Colors.pink,
//               child: const Icon(Icons.add, color: Colors.white),
//               onPressed: () async {
//                 await ApiService.addService({
//                   "icon": Icons.star,
//                   "title": t.newService,
//                   "desc": t.promoService,
//                   "price": "Rp75.000",
//                 });

//                 if (!mounted) return;

//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(content: Text(t.serviceAdded)),
//                 );
//               },
//             )
//           : null,

//       body: CustomScrollView(
//         slivers: [
//           /* ================= HEADER ================= */
//           SliverAppBar(
//             expandedHeight: 120,
//             pinned: true,
//             backgroundColor: Colors.white,
//             flexibleSpace: FlexibleSpaceBar(
//               titlePadding:
//                   const EdgeInsets.only(left: 16, bottom: 16),
//               title: Text(
//                 t.helloUser(_userName),
//                 style: const TextStyle(
//                   color: Colors.black,
//                   fontSize: 16,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//             actions: [
//               IconButton(
//                 icon: const Icon(Icons.receipt_long, color: Colors.pink),
//                 onPressed: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (_) => const OrdersPage(),
//                     ),
//                   );
//                 },
//               ),
//             ],
//           ),

//           /* ================= PROMO ================= */
//           SliverToBoxAdapter(
//             child: Padding(
//               padding: const EdgeInsets.all(16),
//               child: PromoBanner(
//                 title: t.specialPromo,
//                 subtitle: t.discountPromo,
//                 image: "assets/logo.png",
//                 onTap: () {},
//               ),
//             ),
//           ),

//           /* ================= SERVICES ================= */
//           StreamBuilder<List<Map<String, dynamic>>>(
//             stream: ApiService.servicesStream,
//             builder: (context, snapshot) {
//               if (!snapshot.hasData) {
//                 return const SliverFillRemaining(
//                   child: Center(
//                     child: CircularProgressIndicator(color: Colors.pink),
//                   ),
//                 );
//               }

//               final services = snapshot.data!;

//               return SliverList(
//                 delegate: SliverChildBuilderDelegate(
//                   (context, i) {
//                     final s = services[i];

//                     final card = Padding(
//                       padding: EdgeInsets.fromLTRB(
//                         16,
//                         0,
//                         16,
//                         i == services.length - 1 ? 90 : 16,
//                       ),
//                       child: ServiceCard(
//                         icon: s["icon"],
//                         title: s["title"],
//                         description: s["desc"],
//                         price: s["price"],
//                         onPressed: () {
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                               builder: (_) =>
//                                   OrderPage(serviceName: s["title"]),
//                             ),
//                           );
//                         },
//                       ),
//                     );

//                     // 🔐 ADMIN CAN DELETE
//                     return _isAdmin
//                         ? Dismissible(
//                             key: ValueKey(s['title']),
//                             direction: DismissDirection.endToStart,
//                             background: Container(
//                               color: Colors.red,
//                               alignment: Alignment.centerRight,
//                               padding:
//                                   const EdgeInsets.only(right: 20),
//                               child: const Icon(Icons.delete,
//                                   color: Colors.white),
//                             ),
//                             onDismissed: (_) async {
//                               await ApiService.removeServiceAt(i);
//                             },
//                             child: card,
//                           )
//                         : card;
//                   },
//                   childCount: services.length,
//                 ),
//               );
//             },
//           ),
//         ],
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart'; // Import AdMob
import '../widgets/service_card.dart';
import '../widgets/promo_banner.dart';
import '../api/api_service.dart';
import 'order_page.dart';
import 'orders_page.dart';
import '../l10n/app_localizations.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _isAdmin = false;
  String _userName = "User";

  // Variabel untuk AdMob
  BannerAd? _bannerAd;
  bool _isAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadInitialData();
    _initBannerAd(); // Inisialisasi iklan saat halaman dibuka
  }

  @override
  void dispose() {
    _bannerAd?.dispose(); // Hapus iklan dari memori saat halaman ditutup
    super.dispose();
  }

  // Fungsi untuk memuat iklan Banner
  void _initBannerAd() {
    _bannerAd = BannerAd(
      size: AdSize.banner,
      // Menggunakan ID Testing resmi dari Google
      adUnitId: 'ca-app-pub-3940256099942544/6300978111', 
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          setState(() => _isAdLoaded = true);
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          debugPrint("AdMob Error: $error");
        },
      ),
      request: const AdRequest(),
    );
    _bannerAd?.load();
  }

  Future<void> _loadInitialData() async {
    final admin = await ApiService.isAdmin();
    final user = FirebaseAuth.instance.currentUser;

    if (!mounted) return;

    setState(() {
      _isAdmin = admin;
      if (user?.email != null) {
        final email = user!.email!;
        _userName = email.split('@').first;
        _userName = _userName[0].toUpperCase() + _userName.substring(1);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: Colors.white,

      // ADMIN ONLY FAB
      floatingActionButton: _isAdmin
          ? FloatingActionButton(
              backgroundColor: Colors.pink,
              child: const Icon(Icons.add, color: Colors.white),
              onPressed: () async {
                await ApiService.addService({
                  "icon": Icons.star,
                  "title": t.newService,
                  "desc": t.promoService,
                  "price": "Rp75.000",
                });

                if (!mounted) return;

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(t.serviceAdded)),
                );
              },
            )
          : null,

      // Implementasi AdMob di bagian bawah layar
      bottomNavigationBar: _isAdLoaded
          ? SizedBox(
              height: _bannerAd!.size.height.toDouble(),
              width: _bannerAd!.size.width.toDouble(),
              child: AdWidget(ad: _bannerAd!),
            )
          : null,

      body: CustomScrollView(
        slivers: [
          /* ================= HEADER ================= */
          SliverAppBar(
            expandedHeight: 120,
            pinned: true,
            backgroundColor: Colors.white,
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: 16, bottom: 16),
              title: Text(
                t.helloUser(_userName),
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.receipt_long, color: Colors.pink),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const OrdersPage(),
                    ),
                  );
                },
              ),
            ],
          ),

          /* ================= PROMO ================= */
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: PromoBanner(
                title: t.specialPromo,
                subtitle: t.discountPromo,
                image: "assets/logo.png",
                onTap: () {},
              ),
            ),
          ),

          /* ================= SERVICES ================= */
          StreamBuilder<List<Map<String, dynamic>>>(
            stream: ApiService.servicesStream,
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const SliverFillRemaining(
                  child: Center(
                    child: CircularProgressIndicator(color: Colors.pink),
                  ),
                );
              }

              final services = snapshot.data!;

              return SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, i) {
                    final s = services[i];

                    final card = Padding(
                      padding: EdgeInsets.fromLTRB(
                        16,
                        0,
                        16,
                        i == services.length - 1 ? 20 : 16,
                      ),
                      child: ServiceCard(
                        icon: s["icon"],
                        title: s["title"],
                        description: s["desc"],
                        price: s["price"],
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  OrderPage(serviceName: s["title"]),
                            ),
                          );
                        },
                      ),
                    );

                    // ADMIN CAN DELETE
                    return _isAdmin
                        ? Dismissible(
                            key: ValueKey(s['title']),
                            direction: DismissDirection.endToStart,
                            background: Container(
                              color: Colors.red,
                              alignment: Alignment.centerRight,
                              padding: const EdgeInsets.only(right: 20),
                              child: const Icon(Icons.delete, color: Colors.white),
                            ),
                            onDismissed: (_) async {
                              await ApiService.removeServiceAt(i);
                            },
                            child: card,
                          )
                        : card;
                  },
                  childCount: services.length,
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}