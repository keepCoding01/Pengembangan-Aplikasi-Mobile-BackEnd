import 'package:flutter/material.dart';
import '../api/api_service.dart';
import '../models/order_model.dart';
import '../pages/order_detail_page.dart';
import '../l10n/app_localizations.dart';

class OrdersPage extends StatefulWidget {
  const OrdersPage({super.key});

  @override
  State<OrdersPage> createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage> {
  late Future<List<OrderModel>> futureOrders;

  @override
  void initState() {
    super.initState();
    futureOrders = _loadOrders();
  }

  Future<List<OrderModel>> _loadOrders() async {
    try {
      final data = await ApiService.getOrders();
      return data.map((e) => OrderModel.fromMap(e)).toList();
    } catch (e) {
      debugPrint("❌ Error load orders: $e");
      rethrow;
    }
  }

  Future<void> _refreshOrders() async {
    if (!mounted) return;
    setState(() {
      futureOrders = _loadOrders();
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: Colors.pink[50],
      appBar: AppBar(
        title: Text(t.myOrders),
        backgroundColor: Colors.pink,
        centerTitle: true,
      ),

      body: RefreshIndicator(
        onRefresh: _refreshOrders,
        child: FutureBuilder<List<OrderModel>>(
          future: futureOrders,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(color: Colors.pink),
              );
            }

            if (snapshot.hasError) {
              return ListView(
                children: [
                  const SizedBox(height: 200),
                  const Icon(Icons.error_outline,
                      color: Colors.red, size: 48),
                  const SizedBox(height: 10),
                  Center(child: Text(t.loadOrderFailed)),
                ],
              );
            }

            final orders = snapshot.data ?? [];

            if (orders.isEmpty) {
              return ListView(
                children: [
                  const SizedBox(height: 200),
                  Center(
                    child: Text(
                      t.noOrders,
                      style: const TextStyle(
                          fontSize: 18, color: Colors.grey),
                    ),
                  ),
                ],
              );
            }

            return ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: orders.length,
              separatorBuilder: (_, __) => const SizedBox(height: 16),
              itemBuilder: (context, index) {
                final order = orders[index];
                final orderMap = order.toMap()..['id'] = order.id;

                return GestureDetector(
                  onTap: () async {
                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            OrderDetailPage(order: orderMap),
                      ),
                    );

                    if (result == true) {
                      _refreshOrders();
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 6,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          order.service,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.pink,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text("${t.address}: ${order.alamat}"),
                        Text("${t.paymentMethod}: ${order.metode}"),
                        const SizedBox(height: 8),
                        Text(
                          "${t.status}: ${order.status}",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: order.status == "Selesai"
                                ? Colors.green
                                : Colors.orange,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Text(
                            order.tanggal.length >= 16
                                ? order.tanggal.substring(0, 16)
                                : order.tanggal,
                            style: TextStyle(
                              color: Colors.grey.shade600,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
