import 'package:flutter/material.dart';
import '../theme/theme_provider.dart';
import '../localization/locale_provider.dart';
import '../l10n/app_localizations.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool notif = true;
  bool darkMode = ThemeProvider.currentMode == ThemeMode.dark;

  String languageCode = LocaleProvider.currentLocale.languageCode;

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(title: Text(t.settings)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            value: notif,
            title: Text(t.notification),
            onChanged: (v) => setState(() => notif = v),
          ),
          SwitchListTile(
            value: darkMode,
            title: Text(t.darkMode),
            onChanged: (v) {
              setState(() => darkMode = v);
              ThemeProvider.toggleTheme(v);
            },
          ),
          const SizedBox(height: 16),
          Text(t.language, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          DropdownButtonFormField<String>(
            value: languageCode,
            items: const [
              DropdownMenuItem(value: 'id', child: Text("Indonesia")),
              DropdownMenuItem(value: 'en', child: Text("English")),
              DropdownMenuItem(value: 'de', child: Text("Deutsch")),
              DropdownMenuItem(value: 'zh', child: Text("中文")),
            ],
            onChanged: (v) async {
              if (v == null) return;
              await LocaleProvider.setLocale(v);
              setState(() => languageCode = v);
            },
          ),
        ],
      ),
    );
  }
}
