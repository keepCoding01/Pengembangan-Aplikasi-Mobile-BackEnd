import 'dart:async';

class LoadingStream {
  static Stream<int> progressStream() async* {
    for (int i = 0; i <= 100; i += 20) {
      await Future.delayed(const Duration(milliseconds: 120));
      yield i;
    }
  }
}
