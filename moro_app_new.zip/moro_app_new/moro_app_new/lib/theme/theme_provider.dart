import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider {
  static final StreamController<ThemeMode> _themeController =
      StreamController<ThemeMode>.broadcast();

  static ThemeMode _currentMode = ThemeMode.light;

  static Stream<ThemeMode> get themeStream => _themeController.stream;

  static ThemeMode get currentMode => _currentMode;

  static Future<void> loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final isDark = prefs.getBool('isDarkTheme') ?? false;
    _currentMode = isDark ? ThemeMode.dark : ThemeMode.light;
    _themeController.add(_currentMode);
  }

  static Future<void> toggleTheme(bool isDark) async {
    _currentMode = isDark ? ThemeMode.dark : ThemeMode.light;
    _themeController.add(_currentMode);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDarkTheme', isDark);
  }

  static void dispose() {
    _themeController.close();
  }
}
