
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class TeamPrefsService {
  static const _keyMembers = 'team_members_list';

  static Future<void> saveMembers(List<String> members) async {
    final prefs = await SharedPreferences.getInstance();
    final membersJson = jsonEncode(members);
    await prefs.setString(_keyMembers, membersJson);
    print("✅ Daftar anggota tim berhasil disimpan ke Shared Preferences.");
  }

  static Future<List<String>> loadMembers() async {
    final prefs = await SharedPreferences.getInstance();
    final membersJson = prefs.getString(_keyMembers);

    if (membersJson == null) {
      return [
        "Nama Anggota 1 (Ketua)",
        "Nama Anggota 2",
        "Nama Anggota 3",
        "Nama Anggota 4",
      ];
    }
    
    try {
      final List<dynamic> list = jsonDecode(membersJson);
      return list.map((item) => item as String).toList();
    } catch (e) {
      print("❌ Gagal decode JSON dari Shared Preferences: $e");
      return [
        "Nama Anggota Default (Error Loading)",
      ];
    }
  }
}