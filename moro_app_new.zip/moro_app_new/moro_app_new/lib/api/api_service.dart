import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../models/order_model.dart';

class ApiService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  static String? get userId => _auth.currentUser?.uid;
  static String? getLoggedUser() => _auth.currentUser?.email;

  /* ================= AUTH ================= */

  static Future<bool> register(String email, String pass) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: pass.trim(),
      );

      await _firestore.collection('users').doc(cred.user!.uid).set({
        'email': email.trim(),
        'role': 'user',
        'createdAt': FieldValue.serverTimestamp(),
      });

      return true;
    } catch (e) {
      debugPrint("Register error: $e");
      return false;
    }
  }

  static Future<String?> login(String email, String pass) async {
    final cred = await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: pass.trim(),
    );

    final doc =
        await _firestore.collection('users').doc(cred.user!.uid).get();
    return doc.data()?['role'];
  }

  static Future<void> logout() async {
    await _auth.signOut();
  }

  /* ================= ROLE ================= */

  static Future<bool> isAdmin() async {
    if (userId == null) return false;

    final doc =
        await _firestore.collection('users').doc(userId).get();
    return doc.data()?['role'] == 'admin';
  }

  /* ================= SERVICES (UI HOME) ================= */
  

  static final List<Map<String, dynamic>> _services = [
    {
      "icon": Icons.cleaning_services,
      "title": "Basic Cleaning",
      "desc": "Pembersihan ringan",
      "price": "Rp50.000",
    },
    {
      "icon": Icons.cleaning_services_outlined,
      "title": "Deep Cleaning",
      "desc": "Pembersihan menyeluruh",
      "price": "Rp150.000",
    },
  ];

  static final StreamController<List<Map<String, dynamic>>>
      _servicesController =
      StreamController<List<Map<String, dynamic>>>.broadcast();

  static Stream<List<Map<String, dynamic>>> get servicesStream {
    _servicesController.add(List.from(_services));
    return _servicesController.stream;
  }

  // ADMIN ONLY
  static Future<void> addService(Map<String, dynamic> service) async {
    if (!await isAdmin()) {
      throw Exception("Akses ditolak (bukan admin)");
    }

    _services.add(service);
    _servicesController.add(List.from(_services));
  }

  // ADMIN ONLY
  static Future<void> removeServiceAt(int index) async {
    if (!await isAdmin()) {
      throw Exception("Akses ditolak (bukan admin)");
    }

    if (index < 0 || index >= _services.length) return;

    _services.removeAt(index);
    _servicesController.add(List.from(_services));
  }

  /* ================= ORDERS ================= */

  // USER CREATE ORDER
  static Future<bool> createOrder(
    String service,
    String alamat,
    String metode,
  ) async {
    if (userId == null) return false;

    final order = OrderModel(
      service: service,
      alamat: alamat,
      metode: metode,
      status: "Menunggu",
      tanggal: DateTime.now().toIso8601String(),
    );

    try {
      await _firestore.collection('orders').add({
        ...order.toMap(),
        'userId': userId,
      });
      return true;
    } catch (e) {
      debugPrint("Create order error: $e");
      return false;
    }
  }

  // USER: own orders | ADMIN: all orders
  static Future<List<Map<String, dynamic>>> getOrders() async {
    if (userId == null) return [];

    final admin = await isAdmin();
    Query query = _firestore.collection('orders');

    if (!admin) {
      query = query.where('userId', isEqualTo: userId);
    }

    final snap = await query.orderBy('tanggal', descending: true).get();

    return snap.docs.map((d) {
      final data = d.data() as Map<String, dynamic>;
      data['id'] = d.id;
      return data;
    }).toList();
  }

  //  ADMIN ONLY
  static Future<void> updateOrderStatus(
      String orderId, String newStatus) async {
    if (!await isAdmin()) {
      throw Exception("Akses ditolak (bukan admin)");
    }

    await _firestore
        .collection('orders')
        .doc(orderId)
        .update({'status': newStatus});
  }

  //  ADMIN ONLY
  static Future<void> deleteOrder(String orderId) async {
    if (!await isAdmin()) {
      throw Exception("Akses ditolak (bukan admin)");
    }

    await _firestore.collection('orders').doc(orderId).delete();
  }
}
