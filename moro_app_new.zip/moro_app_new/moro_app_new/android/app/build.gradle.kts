android {
    namespace = "com.example.moro_app_new"
    compileSdk = 35      // <-- ganti dari 33 ke 35
    ndkVersion = "27.0.12077973"

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }

    defaultConfig {
        applicationId = "com.example.moro_app_new"
        minSdk = 23
        targetSdk = 35     // sebaiknya samakan dengan compileSdk
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    apply plugin: "com.google.gms.google-services"
}

