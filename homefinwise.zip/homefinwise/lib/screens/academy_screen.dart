import 'package:flutter/material.dart';
import '../models/modul.dart';
import '../widgets/modul_card.dart';
import 'detail_screen.dart';


// ===================== DATA MODUL =========================

// Modul Belajar Dasar Investasi
final List<Modul> belajarInvestasi = [
  Modul(
    title: "Apa itu Investasi?",
    image: "assets/invest1.png",
    chapter: "Chapter 1",
    presenter: "Ricky Susanto Joeng, CFP",
    videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4",
    learningPoints: [
      "Pemahaman dasar investasi dan kenapa investasi itu penting",
      "Pilihan jenis-jenis investasi dan mengenal profil risiko investor",
      "Faktor penting dan strategi dalam berinvestasi",
    ],
    nextChapters: [
      Modul(
        title: "Mengenal Profil Resiko Investasi",
        image: "assets/invest1.png",
        chapter: "Chapter 2",
      ),
      Modul(
        title: "Strategi Investasi yang Tepat",
        image: "assets/invest1.png",
        chapter: "Chapter 3",
      ),
    ]
  ),
  Modul(
    title: "Mengenal Profil Resiko Investasi",
    image: "assets/invest1.png",
    chapter: "Chapter 2",
    presenter: "Ricky Susanto Joeng, CFP",
    videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4",
    learningPoints: [
      "Mengenali tipe-tipe resiko investasi",
      "Cara menentukan profil risiko diri sendiri",
      "Memilih produk investasi sesuai profil risiko"
    ],
    nextChapters: [
      Modul(
        title: "Strategi Investasi yang Tepat",
        image: "assets/invest1.png",
        chapter: "Chapter 3",
      ),
    ]
  ),
  Modul(
    title: "Strategi Investasi yang Tepat",
    image: "assets/invest1.png",
    chapter: "Chapter 3",
    presenter: "Ricky Susanto Joeng, CFP",
    videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4",
    learningPoints: [
      "Strategi jangka panjang vs jangka pendek",
      "Diversifikasi portofolio investasi",
      "Tips memilih instrumen investasi yang cocok",
    ],
    nextChapters: [],
  ),
];

// Modul Reksadana
final List<Modul> reksadana = [
  Modul(
    title: "Pengenalan Reksadana",
    image: "assets/reksadana1.png",
    chapter: "Chapter 1",
    presenter: "Nadia Miranti, S.E., M.M.",
    videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4",
    learningPoints: [
      "Apa itu reksadana pasar uang",
      "Keunggulan dan resiko reksadana",
      "Cara membeli reksadana"
    ],
    nextChapters: [
      Modul(
        title: "Cara Kerja Reksadana",
        image: "assets/reksadana1.png",
        chapter: "Chapter 2",
      ),
      Modul(
        title: "Memilih Reksadana Terbaik",
        image: "assets/reksadana1.png",
        chapter: "Chapter 3",
      ),
    ]
  ),
  Modul(
    title: "Cara Kerja Reksadana",
    image: "assets/reksadana1.png",
    chapter: "Chapter 2",
    presenter: "Nadia Miranti, S.E., M.M.",
    videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4",
    learningPoints: [
      "Alur dana reksadana dari investor ke manajer investasi",
      "Bagaimana keuntungan diperoleh di reksadana"
    ],
    nextChapters: [
      Modul(
        title: "Memilih Reksadana Terbaik",
        image: "assets/reksadana1.png",
        chapter: "Chapter 3",
      ),
    ]
  ),
  Modul(
    title: "Memilih Reksadana Terbaik",
    image: "assets/reksadana1.png",
    chapter: "Chapter 3",
    presenter: "Nadia Miranti, S.E., M.M.",
    videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4",
    learningPoints: [
      "Tips dan kriteria memilih reksadana sesuai tujuan",
      "Kesalahan umum saat berinvestasi di reksadana"
    ],
    nextChapters: [],
  ),
];

// Modul Basic Personal Finance
final List<Modul> personalFinance = [
  Modul(
    title: "Atur Keuangan Pribadi",
    image: "assets/finance1.png",
    chapter: "Chapter 1",
    presenter: "Yoga Pratama, CFP",
    videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4",
    learningPoints: [
      "Konsep dasar keuangan pribadi",
      "Mengatur pemasukan dan pengeluaran",
      "Pentingnya mencatat keuangan"
    ],
    nextChapters: [
      Modul(
        title: "Tips Menabung Efektif",
        image: "assets/finance1.png",
        chapter: "Chapter 2",
      ),
      Modul(
        title: "Pentingnya Dana Darurat",
        image: "assets/finance1.png",
        chapter: "Chapter 3",
      ),
    ]
  ),
  Modul(
    title: "Tips Menabung Efektif",
    image: "assets/finance1.png",
    chapter: "Chapter 2",
    presenter: "Yoga Pratama, CFP",
    videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4",
    learningPoints: [
      "Strategi menabung yang mudah dijalani",
      "Menentukan nominal tabungan yang ideal",
      "Cara disiplin menabung"
    ],
    nextChapters: [
      Modul(
        title: "Pentingnya Dana Darurat",
        image: "assets/finance1.png",
        chapter: "Chapter 3",
      ),
    ]
  ),
  Modul(
    title: "Pentingnya Dana Darurat",
    image: "assets/finance1.png",
    chapter: "Chapter 3",
    presenter: "Yoga Pratama, CFP",
    videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4",
    learningPoints: [
      "Mengapa dana darurat penting",
      "Cara menyiapkan dana darurat",
      "Membedakan kebutuhan & keinginan",
    ],
    nextChapters: [],
  ),
];

// ===================== END DATA MODUL =====================

// ===================== UI SCREEN ==========================
class AcademyScreen extends StatelessWidget {
  const AcademyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCF6FF),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // HEADER
                Center(
                  child: Column(
                    children: [
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.arrow_back, color: Colors.black),
                            onPressed: () => Navigator.pop(context),
                          ),
                          const Expanded(
                            child: Center(
                              child: Text(
                                "FINWISE ACADEMY",
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                ),
                              ),
                            ),
                          ),
                          Opacity(
                            opacity: 0,
                            child: IconButton(
                              icon: const Icon(Icons.arrow_back),
                              onPressed: null,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text(
                                  "Belajar investasi bagi kaum",
                                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                                ),
                                Text(
                                  "sobat muda dari 0 dan",
                                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                                ),
                                Text(
                                  "GRATIS",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: Colors.black,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 18),
                          Image.asset(
                            "assets/academy.png",
                            height: 68,
                            width: 68,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 28),

                // MODUL PEMBELAJARAN
                const Text(
                  "Modul Pembelajaran",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
                const SizedBox(height: 16),
                const Divider(),

                // Section 1
                _SectionList(
                  title: "Belajar Dasar Investasi",
                  items: belajarInvestasi,
                ),
                const SizedBox(height: 18),

                // Section 2
                _SectionList(
                  title: "Reksadana",
                  items: reksadana,
                ),
                const SizedBox(height: 18),

                // Section 3
                _SectionList(
                  title: "Basic Personal Finance",
                  items: personalFinance,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SectionList extends StatelessWidget {
  final String title;
  final List<Modul> items;

  const _SectionList({required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 220,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: items.length,
            separatorBuilder: (context, i) => const SizedBox(width: 18),
            itemBuilder: (context, i) => ModulCard(
              modul: items[i],
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DetailScreen(modul: items[i]),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}
