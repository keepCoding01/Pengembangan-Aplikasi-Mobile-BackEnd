import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'login_page.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  String minat = "Sangat Tertarik";
  final List<String> minatList = [
    "Sangat Tertarik",
    "Cukup Tertarik",
    "Mau Coba Dulu",
    "Belum Tahu",
  ];
  final emailController = TextEditingController();
  final passController = TextEditingController();
  final ulangiPassController = TextEditingController();
  bool subscribeTips = true;
  bool isPasswordVisible = false;
  bool isUlangiPasswordVisible = false;
  bool isLoading = false;

  bool get isFormValid =>
      emailController.text.isNotEmpty &&
      passController.text.isNotEmpty &&
      ulangiPassController.text.isNotEmpty &&
      passController.text == ulangiPassController.text;

  @override
  void dispose() {
    emailController.dispose();
    passController.dispose();
    ulangiPassController.dispose();
    super.dispose();
  }

  void showSuccessSnackbar(BuildContext context, String message) {
    final double statusBar = MediaQuery.of(context).padding.top;
    final snackBar = SnackBar(
      content: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.green[600],
            borderRadius: BorderRadius.circular(30),
          ),
          child: Text(
            message,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ),
      ),
      behavior: SnackBarBehavior.floating,
      elevation: 0,
      backgroundColor: Colors.transparent,
      duration: const Duration(seconds: 2),
      margin: EdgeInsets.only(
        top: statusBar + 32,
        left: 24,
        right: 24,
      ),
    );
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(snackBar);
  }

  void _showTipDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Tips Pendaftaran"),
        content: const Text("Pastikan email kamu aktif & gunakan password yang kuat ya!"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Oke!"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF7DE),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color(0xFFFDC434),
        title: const Text(
          "Register",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
            letterSpacing: 0.5,
          ),
        ),
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
            child: Banner(
              message: "Gabung Komunitas",
              location: BannerLocation.topEnd,
              color: Colors.orange.shade300,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.amber.withOpacity(0.17),
                      blurRadius: 24,
                      offset: const Offset(0, 6),
                    )
                  ],
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Row(
                        children: const [
                          Text(
                            "Yuk, gabung jadi investor ",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                              color: Color(0xFFFFB700),
                            ),
                          ),
                          Icon(Icons.favorite, color: Color(0xFFFFB700), size: 22)
                        ],
                      ),
                      const SizedBox(height: 18),

                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          "Seberapa tertarik kamu?",
                          style: TextStyle(color: Colors.grey[700], fontSize: 14),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(bottom: 18, top: 2),
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: DropdownButtonFormField<String>(
                          value: minat,
                          items: minatList.map((e) {
                            return DropdownMenuItem<String>(
                              value: e,
                              child: Text(e),
                            );
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) setState(() => minat = val);
                          },
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                            contentPadding: EdgeInsets.all(0),
                          ),
                          style: const TextStyle(fontSize: 16, color: Colors.black),
                          icon: const Icon(Icons.keyboard_arrow_down_rounded),
                        ),
                      ),

                      TextFormField(
                        controller: emailController,
                        decoration: _inputDecoration("Email"),
                        keyboardType: TextInputType.emailAddress,
                        validator: (value) {
                          if (value == null || value.isEmpty) return "Email wajib diisi";
                          if (!RegExp(r"^[\w\.-]+@[\w\.-]+\.\w+$").hasMatch(value)) {
                            return "Email tidak valid";
                          }
                          return null;
                        },
                        onChanged: (_) => setState(() {}),
                      ),
                      const SizedBox(height: 16),

                      TextFormField(
                        controller: passController,
                        obscureText: !isPasswordVisible,
                        decoration: _inputDecoration("Password").copyWith(
                          suffixIcon: IconButton(
                            icon: Icon(
                              isPasswordVisible ? Icons.visibility : Icons.visibility_off,
                            ),
                            onPressed: () => setState(() => isPasswordVisible = !isPasswordVisible),
                          ),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) return "Password wajib diisi";
                          if (value.length < 6) return "Minimal 6 karakter";
                          return null;
                        },
                        onChanged: (_) => setState(() {}),
                      ),
                      const SizedBox(height: 16),

                      TextFormField(
                        controller: ulangiPassController,
                        obscureText: !isUlangiPasswordVisible,
                        decoration: _inputDecoration("Ulangi Password").copyWith(
                          suffixIcon: IconButton(
                            icon: Icon(
                              isUlangiPasswordVisible ? Icons.visibility : Icons.visibility_off,
                            ),
                            onPressed: () => setState(() => isUlangiPasswordVisible = !isUlangiPasswordVisible),
                          ),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) return "Ulangi password wajib diisi";
                          if (value != passController.text) return "Password tidak sama";
                          return null;
                        },
                        onChanged: (_) => setState(() {}),
                      ),
                      const SizedBox(height: 18),

                      Row(
                        children: [
                          Switch(
                            value: subscribeTips,
                            onChanged: (val) => setState(() => subscribeTips = val),
                            activeColor: const Color(0xFFFDC434),
                          ),
                          const Text("Langganan tips 📧"),
                        ],
                      ),
                      const SizedBox(height: 18),

                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: isFormValid && !isLoading
                              ? () async {
                                  if (_formKey.currentState?.validate() == true) {
                                    setState(() => isLoading = true);
                                    await Future.delayed(const Duration(seconds: 3));
                                    setState(() => isLoading = false);
                                    showSuccessSnackbar(context, "Registrasi berhasil!");
                                    await Future.delayed(const Duration(seconds: 2));
                                    if (!mounted) return;
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(builder: (_) => const LoginPage()),
                                    );
                                  }
                                }
                              : null,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFFFB700),
                            disabledBackgroundColor: Colors.amber.shade100,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(22),
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: const Text("Daftar Sekarang"),
                        ),
                      ),
                      if (isLoading)
                        const Padding(
                          padding: EdgeInsets.only(top: 14.0),
                          child: CircularProgressIndicator(
                            color: Color(0xFFFFB700),
                            strokeWidth: 3,
                          ),
                        ),
                      const SizedBox(height: 10),

                      TextButton(
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (_) => const LoginPage()),
                          );
                        },
                        child: const Text(
                          "Sudah punya akun? Login",
                          style: TextStyle(
                            color: Color(0xFFFFB700),
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          Positioned(
            bottom: 20,
            right: 20,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                FloatingActionButton(
                  heroTag: "tip_daftar",
                  mini: true,
                  backgroundColor: Colors.orange.shade300,
                  onPressed: _showTipDialog,
                  tooltip: 'Tips Pendaftaran',
                  child: const Icon(Icons.info_outline),
                ),
                const SizedBox(height: 8),
                FloatingActionButton(
                  heroTag: "bantuan",
                  mini: true,
                  backgroundColor: Colors.orange.shade300,
                  onPressed: () {
                    Fluttertoast.showToast(
                      msg: "Hubungi admin di support@investku.com 💬",
                      toastLength: Toast.LENGTH_LONG,
                    );
                  },
                  tooltip: 'Butuh Bantuan?',
                  child: const Icon(Icons.help_outline),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) => InputDecoration(
        hintText: hint,
        contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        fillColor: Colors.grey[50],
        filled: true,
        hintStyle: const TextStyle(fontWeight: FontWeight.w400),
      );
}
