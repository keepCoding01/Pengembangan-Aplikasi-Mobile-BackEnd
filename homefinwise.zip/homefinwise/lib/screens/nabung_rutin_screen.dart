import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'nabung_rutin_form_screen.dart';


class NabungRutinScreen extends StatefulWidget {
  const NabungRutinScreen({Key? key}) : super(key: key);

  @override
  State<NabungRutinScreen> createState() => _NabungRutinScreenState();
}

class _NabungRutinScreenState extends State<NabungRutinScreen> {
  List<Map<String, dynamic>> _jadwalList = [];

  String getBulanNama(int? bulanIdx) {
    const List<String> bulanList = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    if (bulanIdx == null || bulanIdx < 0 || bulanIdx > 11) return "-";
    return bulanList[bulanIdx];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
          children: [
            SizedBox(
              height: 44,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: IconButton(
                      icon: const Icon(Icons.arrow_back_outlined, color: Colors.black),
                      onPressed: () => Navigator.pop(context),
                      splashRadius: 24,
                      tooltip: "Kembali",
                    ),
                  ),
                  const Center(
                    child: Text(
                      "Nabung Rutin",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.black
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              height: 160,
              decoration: BoxDecoration(
                color: Color(0xFF3963b1),
                borderRadius: BorderRadius.circular(16),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 16, top: 35, bottom: 12),
                      child: Text(
                        "Pertama !!\nFitur Aktif\nNabung Rutin\nBersama FinWise",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: ClipRRect(
                      borderRadius: const BorderRadius.only(
                        topRight: Radius.circular(16),
                        bottomRight: Radius.circular(16)
                      ),
                      child: Image.asset(
                        'assets/nabungrutin.jpg',
                        fit: BoxFit.cover,
                        height: double.infinity,
                        alignment: Alignment.centerRight,
                      ),

                    )
                  )
                ],
              ),
            ),
            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFFFB800),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  elevation: 0,
                ),
                onPressed: () async {
                  final hasil = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => NabungRutinFormScreen(),
                    ),
                  );
                  if (hasil != null && mounted) {
                    setState(() {
                      _jadwalList.add(hasil);
                    });
                  }
                },
                icon: Icon(
                  FontAwesomeIcons.calendar,
                  color: Colors.white,
                ),
                label: Text(
                  "Buat Jadwal",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),

            Container(
              width: double.infinity,
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Color(0xFFF8F8F8),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Jadwal Nabung Rutin",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 18),
                  _jadwalList.isEmpty
                      ? Center(
                          child: Column(
                            children: [
                              Icon(
                                FontAwesomeIcons.calendarAlt,
                                size: 70,
                                color: Color(0xFFFFB800),
                              ),
                              SizedBox(height: 16),
                              Text(
                                "Kamu belum memiliki jadwal investasi.",
                                style: TextStyle(
                                  color: Color(0xFFFFB800),
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        )
                      : Column(
                          children: _jadwalList
                              .map(
                                (item) => Padding(
                                  padding: const EdgeInsets.only(bottom: 12.0),
                                  child: Container(
                                    width: double.infinity,
                                    padding: EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                      color: Color(0xFFFFDB80).withOpacity(0.5),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          item['nama'] ?? "",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15),
                                        ),
                                        SizedBox(height: 6),
                                        Text(
                                          "Rp${item['nominal']}",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 20),
                                        ),
                                        SizedBox(height: 6),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "Hingga ${item['bulan'] != null && item['tahun'] != null ? getBulanNama(item['bulan']) + " " + item['tahun'].toString() : "-"}",
                                              style: TextStyle(fontSize: 13),
                                            ),
                                            Text(
                                              "Bulanan: Tanggal ${item['tanggal'] ?? '-'}",
                                              style: TextStyle(fontSize: 13),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              )
                              .toList(),
                        ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}


