import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'register_page.dart';
import 'main_navigation.dart';

void showSuccessSnackbar(BuildContext context, String message) {
  final snackBar = SnackBar(
    content: Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.green[600],
          borderRadius: BorderRadius.circular(30),
        ),
        child: Text(
          message,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
      ),
    ),
    behavior: SnackBarBehavior.floating,
    elevation: 0,
    backgroundColor: Colors.transparent,
    duration: const Duration(seconds: 1),
    margin: const EdgeInsets.only(top: 24, left: 24, right: 24),
  );
  ScaffoldMessenger.of(context)
    ..clearSnackBars()
    ..showSnackBar(snackBar);
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  String tipeUser = "Investor Baru";
  final List<String> tipeList = ["Investor Baru", "Investor Lama", "Guest/Trial"];
  final emailController = TextEditingController();
  final passController = TextEditingController();
  bool ingatSaya = false;
  double mood = 0.5;
  bool isPasswordVisible = false;
  bool isLoading = false;

  bool get isFormValid =>
      emailController.text.isNotEmpty && passController.text.isNotEmpty;

  @override
  void dispose() {
    emailController.dispose();
    passController.dispose();
    super.dispose();
  }

  void _showLoginTips() {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        height: 140,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text("Tips Login Aman 🔐", style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text("• Gunakan password yang unik dan kuat"),
            Text("• Jangan bagikan kode OTP kepada siapapun"),
            Text("• Hindari login di perangkat umum"),
          ],
        ),
      ),
    );
  }

  void _onMoreOption(String value) {
    if (value == 'help') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bantuan belum tersedia')),
      );
    } else if (value == 'language') {
      Fluttertoast.showToast(msg: "Fitur ganti bahasa belum aktif");
    } else if (value == 'contact') {
      Fluttertoast.showToast(msg: "Email: support@investasi.com");
    }
  }

  Future<void> _showConfirmDialog(BuildContext context) async {
    bool? result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text("Konfirmasi"),
        content: Text("Apakah kamu yakin ingin login sebagai $tipeUser?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("Batal"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Yakin"),
          ),
        ],
      ),
    );

    if (result == true) {
      setState(() => isLoading = true);
      await Future.delayed(const Duration(seconds: 1));
      setState(() => isLoading = false);

      if (!mounted) return;
      showSuccessSnackbar(context, "Login sukses!");

      await Future.delayed(const Duration(milliseconds: 500));
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const MainNavigation()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF7DE),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color(0xFFFDC434),
        title: const Text(
          "Login",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        actions: [
          Tooltip(
            message: "Tips Login",
            child: IconButton(
              icon: const Icon(Icons.info_outline, color: Colors.white),
              onPressed: _showLoginTips,
            ),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: Colors.white),
            onSelected: _onMoreOption,
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'help', child: Text('Bantuan')),
              PopupMenuItem(value: 'language', child: Text('Ganti Bahasa')),
              PopupMenuItem(value: 'contact', child: Text('Hubungi Admin')),
            ],
          ),
        ],
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color: Colors.amber.withOpacity(0.13),
                    blurRadius: 26,
                    offset: const Offset(0, 6),
                  )
                ],
              ),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("Haii 👋", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 21, color: Color(0xFFFFB700))),
                    const Text("Masuk dulu yuk!", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 21, color: Color(0xFFFFB700))),
                    const SizedBox(height: 15),

                    Text("Tipe Pengguna", style: TextStyle(color: Colors.grey[700], fontSize: 14)),
                    Container(
                      margin: const EdgeInsets.only(bottom: 18, top: 2),
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: DropdownButtonFormField<String>(
                        value: tipeUser,
                        items: tipeList.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                        onChanged: (val) {
                          if (val != null) setState(() => tipeUser = val);
                        },
                        decoration: const InputDecoration(border: InputBorder.none),
                      ),
                    ),

                    TextFormField(
                      controller: emailController,
                      decoration: _inputDecoration("Email"),
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) {
                        if (value == null || value.isEmpty) return "Email wajib diisi";
                        if (!RegExp(r"^[\w\.-]+@[\w\.-]+\.\w+$").hasMatch(value)) {
                          return "Email tidak valid";
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 15),

                    TextFormField(
                      controller: passController,
                      obscureText: !isPasswordVisible,
                      decoration: _inputDecoration("Password").copyWith(
                        suffixIcon: IconButton(
                          icon: Icon(isPasswordVisible ? Icons.visibility : Icons.visibility_off),
                          onPressed: () => setState(() => isPasswordVisible = !isPasswordVisible),
                        ),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) return "Password wajib diisi";
                        if (value.length < 6) return "Minimal 6 karakter";
                        return null;
                      },
                    ),
                    const SizedBox(height: 15),

                    Row(
                      children: [
                        Switch(
                          value: ingatSaya,
                          onChanged: (val) => setState(() => ingatSaya = val),
                          activeColor: const Color(0xFFFDC434),
                        ),
                        const Text("Ingat data Saya"),
                      ],
                    ),
                    const SizedBox(height: 8),

                    const Text("Mood login kamu hari ini?", style: TextStyle(fontSize: 15)),
                    Slider(
                      value: mood,
                      onChanged: (v) => setState(() => mood = v),
                      min: 0,
                      max: 1,
                      divisions: 10,
                      activeColor: const Color(0xFFFFB700),
                      inactiveColor: Colors.grey.shade200,
                    ),
                    const SizedBox(height: 18),

                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: isFormValid && !isLoading
                            ? () async {
                                if (_formKey.currentState?.validate() == true) {
                                  await _showConfirmDialog(context);
                                }
                              }
                            : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFFFB700),
                          disabledBackgroundColor: Colors.amber.shade100,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        child: const Text("Login Sekarang"),
                      ),
                    ),

                    if (isLoading)
                      const Padding(
                        padding: EdgeInsets.only(top: 14.0),
                        child: Center(
                          child: CircularProgressIndicator(
                            color: Color(0xFFFFB700),
                            strokeWidth: 3,
                          ),
                        ),
                      ),
                    const SizedBox(height: 20),

                    Center(
                      child: TextButton(
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (_) => const RegisterPage()),
                          );
                        },
                        child: const Text(
                          "Belum punya akun? Daftar",
                          style: TextStyle(
                            color: Color(0xFFFFB700),
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) => InputDecoration(
        hintText: hint,
        contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        fillColor: Colors.grey[50],
        filled: true,
      );
}
