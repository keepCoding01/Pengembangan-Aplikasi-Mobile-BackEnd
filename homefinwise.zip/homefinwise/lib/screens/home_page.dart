import 'package:flutter/material.dart';
import 'package:homefinwise/screens/academy_screen.dart';
import 'package:homefinwise/screens/nabung_rutin_screen.dart';
import 'package:intl/intl.dart';
import 'topup_page.dart';
import 'package:homefinwise/screens/produk_page.dart';


class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Set<int> selectedBeritaIndex = {0};
  final List<String> beritaKategori = [
    "Reksa Dana",
    "Emas",
    "SBN",
    "Obligasi",
    "THR Lebaran",
  ];
  final Color chipsActiveColor = const Color(0xFFFFB700);

  bool isPortfolioVisible = true;
  int investasiRp = 0;

  final List<List<Map<String, String>>> beritaList = [
    [
      {
        "judul":
            "Pegang Saham BBRI, BMRI, BBNI hingga IMPC, Cuan Reksadana Schroder dan Manulife Melesat",
        "waktu": "2 jam yang lalu"
      },
      {
        "judul":
            "Bank Mandiri Bagikan Dividen Rp43,5 Triliun dan Payout Ratio 78%, Ini Rekomendasi Saham BMRI",
        "waktu": "8 jam yang lalu"
      },
    ],
    [
      {
        "judul":
            "Harga Emas Dunia Naik, Investor Indonesia Semakin Optimis",
        "waktu": "1 jam yang lalu"
      },
      {
        "judul": "Tips Menabung Emas untuk Pemula, Simak Caranya!",
        "waktu": "5 jam yang lalu"
      },
    ],
    [
      {
        "judul":
            "SBN Retail 2025: Kuota Masih Tersedia, Investor Diuntungkan",
        "waktu": "3 jam yang lalu"
      }
    ],
    [
      {
        "judul":
            "Obligasi Negara: Pilihan Investasi Jangka Panjang di 2025",
        "waktu": "Kemarin"
      }
    ],
    [
      {
        "judul":
            "THR Lebaran 2025: Kasih Voucher Gift Bibit, Murah dan Untung",
        "waktu": "12 jam yang lalu"
      }
    ]
  ];

  void _openProdukPage(String label) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProdukPage(produkTitle: label),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> beritaGabungan = [];
    for (var idx in selectedBeritaIndex) {
      beritaGabungan.addAll(beritaList[idx]);
    }

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              backgroundColor: Colors.white,
              
              elevation: 1,
              pinned: true,
              floating: false,
              snap: false,
              expandedHeight: 0,
              centerTitle: false,
              automaticallyImplyLeading: false,
              title: Row(
                children: [
                  Image.asset(
                    'assets/mascot.png',
                    width: 36,
                    height: 36,
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'FinWise',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Colors.black,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.notifications_none),
                    onPressed: () {},
                    color: Colors.black,
                  ),
                ],
              ),
            ),
            SliverList(
              delegate: SliverChildListDelegate([
                // Nilai Portofolio Card
                Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 12,
                        offset: const Offset(0, 3),
                      )
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Nilai Portofolio",
                        style: TextStyle(fontSize: 16),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          const Text(
                            "Rp ",
                            style: TextStyle(fontSize: 16),
                          ),
                          Text(
                            isPortfolioVisible
                                ? NumberFormat.decimalPattern('id_ID')
                                    .format(56000000 + investasiRp)
                                : "•••••••••",
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 22,
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(width: 8),
                          InkWell(
                            onTap: () {
                              setState(() {
                                isPortfolioVisible = !isPortfolioVisible;
                              });
                            },
                            child: Icon(
                              isPortfolioVisible
                                  ? Icons.visibility
                                  : Icons.visibility_off_outlined,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Keuntungan"),
                              Text("Rp0", style: TextStyle(fontWeight: FontWeight.bold)),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text("Imbal Hasil"),
                              Text("0.00%", style: TextStyle(fontWeight: FontWeight.bold)),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Produk Investasi
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      const Icon(Icons.local_florist, color: Color(0xFFFFB700)),
                      const SizedBox(width: 8),
                      const Text(
                        "Produk Investasi",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      GestureDetector(
                        onTap: () => _openProdukPage("Reksadana"),
                        child: _produkInvestasiItem("Reksadana", Icons.savings, Colors.greenAccent),
                      ),
                      GestureDetector(
                        onTap: () => _openProdukPage("Emas"),
                        child: _produkInvestasiItem("Emas", Icons.wallet, Colors.yellowAccent),
                      ),
                      GestureDetector(
                        onTap: () => _openProdukPage("SBN Retail"),
                        child: _produkInvestasiItem("SBN Retail", Icons.account_balance, Colors.blue.shade100),
                      ),
                      GestureDetector(
                        onTap: () => _openProdukPage("Saham"),
                        child: _produkInvestasiItem("Saham", Icons.candlestick_chart, Colors.red.shade100),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                // Portofolio & Nabung Rutin
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      const Icon(Icons.pie_chart_outline, color: Color(0xFFFFB700), size: 20),
                      const SizedBox(width: 8),
                      const Text(
                        "Portofolio",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      const Spacer(),
                      TextButton.icon(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const NabungRutinScreen())
                          );
                        },
                        icon: const Icon(Icons.calendar_month_rounded, color: Color(0xFFFFB700), size: 18),
                        label: const Text(
                          "Nabung Rutin",
                          style: TextStyle(
                              color: Color(0xFFFFB700),
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ),
                // Dana Tabungan
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Dana Tabungan",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text("Investasi"),
                              Text(
                                NumberFormat.currency(
                                        locale: 'id_ID', symbol: 'Rp', decimalDigits: 0)
                                    .format(investasiRp),
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          const Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text("Keuntungan"),
                              Text("Rp0", style: TextStyle(fontWeight: FontWeight.bold)),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () async {
                            final result = await Navigator.push<int>(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const TopUpPage()),
                            );
                            if (result != null && result > 0) {
                              setState(() {
                                investasiRp = result;
                              });
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFFFB700),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: const Text("Top Up"),
                        ),
                      )
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                // Indeks Market
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: const [
                      Text(
                        "Indeks Market",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                _indeksMarketCard(),
                const SizedBox(height: 18),
                // Berita Section
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: const [
                      Icon(Icons.campaign, color: Colors.orange),
                      SizedBox(width: 8),
                      Text(
                        "Berita",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                // Chips multi select
                SizedBox(
                  height: 38,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.only(left: 16, right: 16),
                    itemCount: beritaKategori.length,
                    itemBuilder: (context, idx) {
                      final bool active = selectedBeritaIndex.contains(idx);
                      return Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: FilterChip(
                          label: Text(
                            beritaKategori[idx],
                            style: TextStyle(
                              color: active ? Colors.white : Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          selected: active,
                          selectedColor: chipsActiveColor,
                          backgroundColor: Colors.grey.shade200,
                          showCheckmark: false,
                          onSelected: (val) {
                            setState(() {
                              if (active) {
                                selectedBeritaIndex.remove(idx);
                                if (selectedBeritaIndex.isEmpty) {
                                  selectedBeritaIndex.add(idx);
                                }
                              } else {
                                selectedBeritaIndex.add(idx);
                              }
                            });
                          },
                        ),
                      );
                    },
                  ),
                ),
                // List berita gabungan
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Column(
                    children: beritaGabungan
                        .map((berita) => ListTile(
                              contentPadding: EdgeInsets.zero,
                              title: Text(
                                berita["judul"]!,
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 15),
                              ),
                              subtitle: Text(
                                berita["waktu"]!,
                                style: const TextStyle(fontSize: 12),
                              ),
                              minVerticalPadding: 8,
                            ))
                        .toList(),
                  ),
                ),
                const SizedBox(height: 24),
              ]),
            ),
          ],
        ),
      ),
      floatingActionButton: Tooltip(
        message: "FinWise Academy",
        child: FloatingActionButton(
          backgroundColor: const Color(0xFFFFB700),
          elevation: 4,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => AcademyScreen())
            );
          },
          child: Image.asset(
            'assets/academy.png',
            width: 32,
            height: 32,
          ),
        ),
      ),
    );
  }

  Widget _produkInvestasiItem(String label, IconData icon, Color bgColor) {
    return Column(
      children: [
        Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(50),
          ),
          child: Icon(icon, size: 28, color: Colors.black87),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 12),
        ),
      ],
    );
  }

  Widget _indeksMarketCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _indeksTab("Saham", true),
              const SizedBox(width: 10),
              _indeksTab("Emas", false),
            ],
          ),
          const SizedBox(height: 10),
          const Text(
            "IHSG",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          const SizedBox(height: 6),
          const Text(
            "6.458,96",
            style: TextStyle(fontSize: 16, color: Colors.green, fontWeight: FontWeight.bold),
          ),
          const Text(
            "+223,34 (3,58%) ↑ hari ini",
            style: TextStyle(fontSize: 14, color: Colors.green),
          ),
          const SizedBox(height: 4),
          Container(
            margin: const EdgeInsets.symmetric(vertical: 4),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(8),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                'assets/ihsg_chart.png',
                width: double.infinity,
                fit: BoxFit.fitWidth,
                alignment: Alignment.center,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _indeksTab(String label, bool active) {
    return Container(
      decoration: BoxDecoration(
        color: active ? const Color(0xFFFFB700) : Colors.grey.shade200,
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 18),
      child: Text(
        label,
        style: TextStyle(
          color: active ? Colors.white : Colors.black87,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
