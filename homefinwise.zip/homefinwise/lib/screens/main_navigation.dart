import 'package:flutter/material.dart';


import 'home_page.dart';
import 'explore_page.dart';
import 'transaksi_page.dart';
import 'portofolio_page.dart';
import 'profile_page.dart';

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});
  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _selectedIndex = 0;

  final List<Widget> _screens = const [
    HomePage(),
    TransaksiPage(),
    PortofolioPage(),
    ExplorePage(),
    ProfilePage(),
  ];

  void _onTabTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _screens,
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        onTap: _onTabTapped,
        selectedFontSize: 14,
        unselectedFontSize: 13,
        elevation: 14,
        selectedItemColor: const Color(0xFFFFB700),
        unselectedItemColor: const Color(0xFFFFDB80),
        items: [
          BottomNavigationBarItem(
            icon: _selectedIndex == 0
                ? const Icon(Icons.home_rounded, size: 30)
                : const Icon(Icons.home_outlined, size: 27),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: _selectedIndex == 2
                ? const Icon(Icons.receipt_long, size: 30)
                : const Icon(Icons.receipt_long, size: 27),
            label: "Transaksi",
          ),
          BottomNavigationBarItem(
            icon: _selectedIndex == 3
                ? const Icon(Icons.pie_chart_rounded, size: 30)
                : const Icon(Icons.pie_chart_outline, size: 27),
            label: "Portofolio",
          ),
          BottomNavigationBarItem(
            icon: _selectedIndex == 1
                ? const Icon(Icons.explore_rounded, size: 30)
                : const Icon(Icons.explore_outlined, size: 27),
            label: "Explore",
          ),
          BottomNavigationBarItem(
            icon: _selectedIndex == 4
                ? const Icon(Icons.person_rounded, size: 30)
                : const Icon(Icons.person_outline, size: 27),
            label: "Profile",
          ),
        ],
        selectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.bold,
        ),
        unselectedLabelStyle: const TextStyle(
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
