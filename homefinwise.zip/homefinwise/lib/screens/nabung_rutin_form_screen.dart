import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class NabungRutinFormScreen extends StatefulWidget {
  const NabungRutinFormScreen({Key? key}) : super(key: key);

  @override
  State<NabungRutinFormScreen> createState() => _NabungRutinFormScreenState();
}

class _NabungRutinFormScreenState extends State<NabungRutinFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _namaController = TextEditingController();
  final _nominalController = TextEditingController();

  int? _selectedTanggal;
  int? _selectedBulan;
  int? _selectedTahun;

  final List<int> tahunList = [2025, 2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034, 2035];
  final List<String> bulanList = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];

  @override
  void dispose() {
    _namaController.dispose();
    _nominalController.dispose();
    super.dispose();
  }

  void _showTanggalPicker() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        int tempTanggal = _selectedTanggal ?? 1;
        return _BottomPicker(
          title: 'Pilih Tanggal',
          child: CupertinoPicker(
            scrollController:
                FixedExtentScrollController(initialItem: tempTanggal - 1),
            itemExtent: 36,
            onSelectedItemChanged: (index) {
              tempTanggal = index + 1;
            },
            children:
                List.generate(31, (i) => Center(child: Text('${i + 1}'))),
          ),
          onPilih: () {
            setState(() {
              _selectedTanggal = tempTanggal;
            });
            Navigator.pop(context);
          },
        );
      },
    );
  }

  void _showPeriodePicker() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        int tempBulan = _selectedBulan ?? 0;
        int tempTahun = _selectedTahun ?? tahunList[0];

        return _BottomPicker(
          title: 'Pilih Periode',
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                child: CupertinoPicker(
                  scrollController:
                      FixedExtentScrollController(initialItem: tempBulan),
                  itemExtent: 36,
                  onSelectedItemChanged: (index) {
                    tempBulan = index;
                  },
                  children:
                      bulanList.map((b) => Center(child: Text(b))).toList(),
                ),
              ),
              Expanded(
                child: CupertinoPicker(
                  scrollController: FixedExtentScrollController(
                    initialItem: tahunList.indexOf(tempTahun),
                  ),
                  itemExtent: 36,
                  onSelectedItemChanged: (index) {
                    tempTahun = tahunList[index];
                  },
                  children:
                      tahunList.map((t) => Center(child: Text('$t'))).toList(),
                ),
              ),
            ],
          ),
          onPilih: () {
            setState(() {
              _selectedBulan = tempBulan;
              _selectedTahun = tempTahun;
            });
            Navigator.pop(context);
          },
        );
      },
    );
  }

  String? _validateNominal(String? value) {
    if (value == null || value.isEmpty) return 'Nominal harus diisi';
    final intVal = int.tryParse(value.replaceAll('.', '')) ?? 0;
    if (intVal < 100000) return 'Minimal Rp 100.000';
    return null;
  }

  void _simpanForm() {
    if (_formKey.currentState?.validate() != true) return;

    if (_selectedTanggal == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Pilih tanggal terlebih dahulu')),
      );
      return;
    }
    if (_selectedBulan == null || _selectedTahun == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Pilih periode berakhir terlebih dahulu')),
      );
      return;
    }

    Navigator.pop(context, {
      'nama': _namaController.text,
      'nominal': _nominalController.text,
      'tanggal': _selectedTanggal,
      'bulan': _selectedBulan,
      'tahun': _selectedTahun,
    });
  }

  @override
  Widget build(BuildContext context) {
    const warnaUtama = Color(0xFFFFDB80);

    return Scaffold(
      appBar: AppBar(
        title: Text('Buat Nabung Rutin',
            style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Info Box
              Container(
                padding: EdgeInsets.all(14),
                margin: EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFB700),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Pastikan alarm handphone kamu selalu aktif agar mengingat bahwa kamu ada kegiatan nabung rutin di FinWise Apps',
                  style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
              Text('Nama Jadwal',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              TextFormField(
                controller: _namaController,
                decoration: InputDecoration(
                  hintText: 'Tentukan Nama Nabung Rutinmu',
                  filled: true,
                  fillColor: warnaUtama.withOpacity(0.3),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none),
                ),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Nama jadwal wajib diisi' : null,
              ),
              SizedBox(height: 20),

              Text('Nominal Investasi',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              TextFormField(
                controller: _nominalController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  prefixText: 'Rp ',
                  hintText: 'Min. 100.000',
                  filled: true,
                  fillColor: warnaUtama.withOpacity(0.3),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none),
                ),
                validator: _validateNominal,
              ),
              SizedBox(height: 20),

              Text('Frekuensi', style: TextStyle(fontWeight: FontWeight.bold)),
              Text('Bulanan', style: TextStyle(fontWeight: FontWeight.normal)),
              SizedBox(height: 20),

              Text('Setiap Tanggal',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              GestureDetector(
                onTap: _showTanggalPicker,
                child: Container(
                  width: double.infinity,
                  padding:
                      EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                  decoration: BoxDecoration(
                    color: warnaUtama.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _selectedTanggal != null
                            ? '${_selectedTanggal!}'
                            : 'Pilih Tanggal',
                        style: TextStyle(fontSize: 16),
                      ),
                      Icon(Icons.expand_more),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),

              Text('Periode Berakhir',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              GestureDetector(
                onTap: _showPeriodePicker,
                child: Container(
                  width: double.infinity,
                  padding:
                      EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                  decoration: BoxDecoration(
                    color: warnaUtama.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        (_selectedBulan != null && _selectedTahun != null)
                            ? '${bulanList[_selectedBulan!]} ${_selectedTahun!}'
                            : 'Pilih Periode',
                        style: TextStyle(fontSize: 16),
                      ),
                      Icon(Icons.expand_more),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 32),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _simpanForm,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFFB700),
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                  ),
                  child: Text('Simpan',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BottomPicker extends StatelessWidget {
  final String title;
  final Widget child;
  final VoidCallback onPilih;

  const _BottomPicker({
    required this.title,
    required this.child,
    required this.onPilih,
  });

  @override
  Widget build(BuildContext context) {
    const warnaUtama = Color(0xFFFFDB80);
    return Container(
      padding: EdgeInsets.only(top: 18, left: 16, right: 16, bottom: 8),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(title,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            SizedBox(height: 10),
            SizedBox(height: 150, child: child),
            SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFFFFB700),
                    backgroundColor: const Color(0xFFFFDB80),
                    side: BorderSide(color: const Color(0xFFFFB700)),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text('Batal'),
                ),
                ElevatedButton(
                  onPressed: onPilih,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFFB700),
                    foregroundColor: Colors.white,
                    padding:
                        EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text('Pilih'),
                ),
              ],
            ),
            SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}
