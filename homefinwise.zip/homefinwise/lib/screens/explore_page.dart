import 'package:flutter/material.dart';

class ExplorePage extends StatefulWidget {
  const ExplorePage({Key? key}) : super(key: key);

  @override
  State<ExplorePage> createState() => _ExplorePageState();
}

class _ExplorePageState extends State<ExplorePage> {
  double _sliderValue = 2000000;
  bool showSaham = true;
  bool showObligasi = true;
  bool showSbn = true;
  bool showReksaDana = true;
  String sort = 'Paling Populer';

  List<Map<String, dynamic>> allProducts = [
    {
      'title': 'Reksa Dana Amanah',
      'category': 'Reksa Dana',
      'price': 150000,
      'desc': 'Cocok untuk investor pemula',
      'color': Color(0xFFD1FCD3),
      'icon': Icons.eco
    },
    {
      'title': 'SBN Retail Seri 012',
      'category': 'SBN',
      'price': 1000000,
      'desc': 'Penerbitan negara dengan kupon menarik',
      'color': Color(0xFFFFD6D6),
      'icon': Icons.flag
    },
    {
      'title': 'Obligasi FR76',
      'category': 'Obligasi',
      'price': 2000000,
      'desc': 'Kupon tetap 6.25%',
      'color': Color(0xFFD6E6FF),
      'icon': Icons.savings
    },
    {
      'title': 'Saham ABC',
      'category': 'Saham',
      'price': 95000,
      'desc': 'Saham unggulan sektor teknologi',
      'color': Color(0xFFE7D6FF),
      'icon': Icons.show_chart
    },
  ];

  List<Map<String, dynamic>> get filteredProducts {
    List<Map<String, dynamic>> filtered = allProducts.where((p) {
      if (p['category'] == 'Saham' && !showSaham) return false;
      if (p['category'] == 'Obligasi' && !showObligasi) return false;
      if (p['category'] == 'SBN' && !showSbn) return false;
      if (p['category'] == 'Reksa Dana' && !showReksaDana) return false;
      return p['price'] <= _sliderValue;
    }).toList();

    if (sort == 'Paling Populer') {
      // Urutan: Reksa Dana Amanah, SBN Retail Seri 012, Obligasi FR76, Saham ABC
      filtered.sort((a, b) {
        List<String> order = [
          'Reksa Dana Amanah',
          'SBN Retail Seri 012',
          'Obligasi FR76',
          'Saham ABC'
        ];
        return order.indexOf(a['title']).compareTo(order.indexOf(b['title']));
      });
    } else if (sort == 'Harga Tertinggi') {
      filtered.sort((b, a) => a['price'].compareTo(b['price']));
    } else if (sort == 'Harga Terendah') {
      filtered.sort((a, b) => a['price'].compareTo(b['price']));
    }

    return filtered;
  }

  List<String> watchlist = [];

  void _showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (context) => StatefulBuilder(
        builder: (context, setStateModal) => Padding(
          padding: EdgeInsets.only(
            left: 18,
            right: 18,
            top: 22,
            bottom: MediaQuery.of(context).viewInsets.bottom + 22,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Filter Harga Maksimal',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Text(
                'Rp ${_sliderValue.round().toString()}',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              Slider(
                value: _sliderValue,
                min: 50000,
                max: 2000000,
                divisions: 20,
                label: 'Rp ${_sliderValue.round()}',
                onChanged: (val) => setStateModal(() {
                  setState(() => _sliderValue = val);
                }),
                activeColor: Color(0xFFFFB700),
                inactiveColor: Color(0xFFFFDB80),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFFFB700),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                onPressed: () {
                  Navigator.pop(context);
                  setState(() {});
                },
                child: const Text('Terapkan'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showTipsDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text("Tips Explore 💡"),
        content: const Text(
          "Gunakan filter untuk cari produk terbaik sesuai kebutuhanmu.",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Tutup"),
          ),
        ],
      ),
    );
  }

  void _handleCardTap(Map<String, dynamic> product) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: product['color'],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Row(
          children: [
            Icon(product['icon'], color: Colors.black),
            SizedBox(width: 8),
            Expanded(
              child: Text(
                product['title'],
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            )
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Kategori: ${product['category']}'),
            Text('Harga: Rp ${product['price']}'),
            Text('Deskripsi:'),
            Text(product['desc']),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Color mainColor = const Color(0xFFFFB700); 
    return Scaffold(
      backgroundColor: const Color(0xFFF8F5FC),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: const Padding(
          padding: EdgeInsets.only(left: 2),
          child: Text(
            "Explore",
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontFamily: 'Inter',
              fontSize: 22,
            ),
          ),
        ),
        automaticallyImplyLeading: false,
        toolbarHeight: 56,
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        children: [
          Row(
            children: [
              Expanded(
                child: Container(
                  margin: const EdgeInsets.only(bottom: 10, top: 6, right: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(26),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))
                    ],
                  ),
                  child: Row(
                    children: [
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 12),
                        child: Icon(Icons.search, color: Colors.grey),
                      ),
                      Expanded(
                        child: TextField(
                          style: const TextStyle(fontFamily: 'Inter'),
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "Cari produk investasi",
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Icon filter
              InkWell(
                borderRadius: BorderRadius.circular(99),
                onTap: _showFilterBottomSheet,
                child: SizedBox(
                  height: 60,
                  width: 60,
                  child: const Icon(Icons.filter_alt_rounded, ),
                ),
              )
            ],
          ),
          // Promo Investasi Carousel
          const SizedBox(height: 4),
          const Text(
            "Promo Investasi",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, fontFamily: 'Inter'),
          ),
          const SizedBox(height: 8),
          _buildBannerCarousel(),
          const SizedBox(height: 18),

          Wrap(
            spacing: 8,
            children: [
              const SizedBox(width: 8),
              FilterChip(
                label: const Text('Reksa Dana'
                ),
                selected: showReksaDana,
                onSelected: (v) => setState(() {
                  showReksaDana = v;
                }),
                backgroundColor: Color(0xFFFFDB80),
                selectedColor: Color(0xFFFFB700),
                checkmarkColor: Colors.white,
                labelStyle: const TextStyle(fontFamily: 'Inter'),
              ),
              FilterChip(
                label: const Text('Saham'),
                selected: showSaham,
                onSelected: (v) => setState(() {
                  showSaham = v;
                }),
                backgroundColor: Color(0xFFFFDB80),
                selectedColor: Color(0xFFFFB700),
                checkmarkColor: Colors.white,
                labelStyle: const TextStyle(fontFamily: 'Inter'),
              ),
              FilterChip(
                label: const Text('Obligasi'),
                selected: showObligasi,
                onSelected: (v) => setState(() {
                  showObligasi = v;
                }),
                backgroundColor: Color(0xFFFFDB80),
                selectedColor: Color(0xFFFFB700),
                checkmarkColor: Colors.white,
                labelStyle: const TextStyle(fontFamily: 'Inter'),
              ),
              FilterChip(
                label: const Text('SBN'),
                selected: showSbn,
                onSelected: (v) => setState(() {
                  showSbn = v;
                }),
                backgroundColor: Color(0xFFFFDB80),
                selectedColor: Color(0xFFFFB700),
                checkmarkColor: Colors.white,
                labelStyle: const TextStyle(fontFamily: 'Inter'),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Checkbox Saham & Obligasi di bawah sendiri (ListTile style)
          ListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            horizontalTitleGap: 0,
            title: const Text('Saham', style: TextStyle(fontFamily: 'Inter')),
            trailing: Checkbox(
              value: showSaham,
              activeColor: Color(0xFFFFB700),
              onChanged: (val) => setState(() => showSaham = val!),
            ),
            onTap: () => setState(() => showSaham = !showSaham),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            horizontalTitleGap: 0,
            title: const Text('Obligasi', style: TextStyle(fontFamily: 'Inter')),
            trailing: Checkbox(
              value: showObligasi,
              activeColor: Color(0xFFFFB700),
              onChanged: (val) => setState(() => showObligasi = val!),
            ),
            onTap: () => setState(() => showObligasi = !showObligasi),
          ),
          const SizedBox(height: 4),
          const Text(
            "Urutkan berdasarkan:",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, fontFamily: 'Inter'),
          ),
          RadioListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            value: 'Paling Populer',
            groupValue: sort,
            onChanged: (val) => setState(() => sort = val as String),
            title: const Text('Paling Populer', style: TextStyle(fontFamily: 'Inter')),
            activeColor: Color(0xFFFFB700),
          ),
          RadioListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            value: 'Harga Tertinggi',
            groupValue: sort,
            onChanged: (val) => setState(() => sort = val as String),
            title: const Text('Harga Tertinggi', style: TextStyle(fontFamily: 'Inter')),
            activeColor: Color(0xFFFFB700),
          ),
          RadioListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            value: 'Harga Terendah',
            groupValue: sort,
            onChanged: (val) => setState(() => sort = val as String),
            title: const Text('Harga Terendah', style: TextStyle(fontFamily: 'Inter')),
            activeColor: Color(0xFFFFB700),
          ),
          const SizedBox(height: 8),
          const Text(
            "Produk Investasi",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Inter'),
          ),
          const SizedBox(height: 10),

          _buildProductGrid(),

          const SizedBox(height: 22),

          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            child: Column(
              children: [
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Watchlist',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 15),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.green),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: const EdgeInsets.all(50),
                  child: Column(
                    children: [
                      const Text(
                        "Tambah Produk ke Watchlist",
                        style: TextStyle(
                            color: Colors.green,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Inter'),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        "Simpan produk favoritmu untuk pantau pergerakan harga",
                        style: TextStyle(fontSize: 13, fontFamily: 'Inter'),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 4),
                      if (watchlist.isEmpty)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 3.0),
                          child: Text(
                            "Belum ada produk yang disimpan.",
                            style: TextStyle(fontSize: 13, fontFamily: 'Inter'),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      if (watchlist.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3.0),
                          child: Column(
                            children: watchlist
                                .map((prod) => Text('• $prod',
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(fontFamily: 'Inter')))
                                .toList(),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.amber,
        tooltip: 'Tips Explore',
        onPressed: _showTipsDialog,
        child: const Icon(Icons.lightbulb_outline, color: Colors.white),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }

  Widget _buildProductGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: filteredProducts.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1.20,
        crossAxisSpacing: 14,
        mainAxisSpacing: 14,
      ),
      itemBuilder: (context, index) {
        final prod = filteredProducts[index];
        return GestureDetector(
          onTap: () => _handleCardTap(prod),
          child: Container(
            decoration: BoxDecoration(
              color: prod['color'],
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                    color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))
              ],
            ),
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 14, 8, 14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(prod['title'],
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Inter',
                              fontSize: 15)),
                      const SizedBox(height: 4),
                      Text(prod['desc'],
                          style: TextStyle(
                              fontSize: 12,
                              color: Colors.black54,
                              fontFamily: 'Inter')),
                      const Spacer(),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("Rp ${prod['price']}",
                              style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Inter')),
                          PopupMenuButton(
                            icon: Icon(Icons.more_vert, size: 18, color: Colors.black38),
                            itemBuilder: (_) => [
                              const PopupMenuItem(
                                value: 'watchlist',
                                child: Text('Tambah ke Watchlist'),
                              ),
                            ],
                            onSelected: (value) {
                              if (value == 'watchlist') {
                                setState(() {
                                  watchlist.add(prod['title']);
                                });
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('${prod['title']} ditambahkan ke Watchlist!'),
                                    backgroundColor: Colors.orange,
                                  ),
                                );
                              }
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // Carousel Banner Promo
  final List<String> bannerImages = [
    'assets/banner/banner1.png',
    'assets/banner/banner2.png',
    'assets/banner/banner3.png',
  ];
  int _currentBanner = 0;
  late PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _startAutoScroll();
  }

  void _startAutoScroll() {
    Future.delayed(const Duration(seconds: 3), () {
      if (!mounted) return;
      setState(() {
        _currentBanner = (_currentBanner + 1) % bannerImages.length;
        _pageController.animateToPage(
          _currentBanner,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeInOut,
        );
      });
      _startAutoScroll();
    });
  }

  Widget _buildBannerCarousel() {
    return AspectRatio(
      aspectRatio: 16 / 6,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          alignment: Alignment.bottomCenter,
          children: [
            PageView.builder(
              controller: _pageController,
              onPageChanged: (i) {
                setState(() => _currentBanner = i);
              },
              itemCount: bannerImages.length,
              itemBuilder: (context, i) => Image.asset(
                bannerImages[i],
                fit: BoxFit.cover, 
              ),
            ),
            Positioned(
              bottom: 10,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  bannerImages.length,
                  (i) => Container(
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: _currentBanner == i ? Color(0xFFFFB700) : Colors.white54,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
