import 'package:flutter/material.dart';


class PortofolioPage extends StatefulWidget {
  const PortofolioPage({Key? key}) : super(key: key);

  @override
  State<PortofolioPage> createState() => _PortofolioPageState();
}

class _PortofolioPageState extends State<PortofolioPage> {
  bool showActiveOnly = false;
  String selectedCategory = "Semua";
  final TextEditingController _searchController = TextEditingController();

  bool _showAmount = false;
  int _portfolioValue = 265000;
  final _moneyFormat = (int n) =>
      "${n.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => '.')}";

  String chipsSelected = "Semua";
  List<String> chipTitles = ["Pasar Uang", "Obligasi", "Saham"];

  List<Map<String, dynamic>> portfolios = [
    {
      "title": "Dana Tabungan",
      "category": "Pasar Uang",
      "productCount": 3,
      "value": 5600000,
      "profit": 300000,
      "icon": Icons.savings,
    },
    {
      "title": "Bibit Saham",
      "category": "Saham",
      "productCount": 1,
      "value": 1500000,
      "profit": 1200000,
      "icon": Icons.stacked_line_chart,
    },
    {
      "title": "Obligasi",
      "category": "Obligasi",
      "productCount": 5,
      "value": 20000000,
      "profit": 1500000,
      "icon": Icons.account_balance_wallet,
    }
  ];

  List<Map<String, dynamic>> get filteredPortfolios {
    String search = _searchController.text.toLowerCase();
    return portfolios.where((p) {
      bool matchesChips = (chipsSelected == "Semua") ||
          p["category"].toLowerCase() == chipsSelected.toLowerCase();
      bool matchesSearch =
          search.isEmpty || p["title"].toLowerCase().contains(search);
      return matchesChips && matchesSearch;
    }).toList();
  }

  void _showSheet() {
    final TextEditingController nameController = TextEditingController();
    String? selectedKategori;
    DateTime? selectedDate;
    TimeOfDay? selectedTime;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFF8F5FC),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            left: 24,
            right: 24,
            bottom: MediaQuery.of(context).viewInsets.bottom + 24,
            top: 24,
          ),
          child: StatefulBuilder(
            builder: (context, setModalState) {
              return SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Tambah Portofolio",
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 20),
                    TextField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        labelText: "Nama Portofolio",
                        border: UnderlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 20),
                    DropdownButtonFormField<String>(
                      value: selectedKategori,
                      hint: const Text("Pilih Kategori"),
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                      ),
                      items: ['Pasar Uang', 'Saham', 'Obligasi']
                          .map((String val) {
                        return DropdownMenuItem(
                            value: val, child: Text(val));
                      }).toList(),
                      onChanged: (val) => setModalState(() => selectedKategori = val),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            backgroundColor: const Color(0xFFFFB700),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16)),
                          ),
                          onPressed: () async {
                            final date = await showDatePicker(
                              context: context,
                              initialDate: DateTime.now(),
                              firstDate: DateTime(2020),
                              lastDate: DateTime(2100),
                            );
                            if (date != null) {
                              setModalState(() => selectedDate = date);
                            }
                          },
                          icon: const Icon(Icons.calendar_today, size: 20),
                          label: const Text("Tanggal"),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          selectedDate == null
                              ? "Belum dipilih"
                              : "${selectedDate!.day.toString().padLeft(2, '0')}/${selectedDate!.month.toString().padLeft(2, '0')}/${selectedDate!.year}",
                          style: const TextStyle(fontSize: 15),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            backgroundColor: const Color(0xFFFFB700),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16)),
                          ),
                          onPressed: () async {
                            final time = await showTimePicker(
                              context: context,
                              initialTime: TimeOfDay.now(),
                            );
                            if (time != null) {
                              setModalState(() => selectedTime = time);
                            }
                          },
                          icon: const Icon(Icons.access_time, size: 20),
                          label: const Text("Waktu"),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          selectedTime == null
                              ? "Belum dipilih"
                              : selectedTime!.format(context),
                          style: const TextStyle(fontSize: 15),
                        ),
                      ],
                    ),
                    const SizedBox(height: 28),
                    Align(
                      alignment: Alignment.centerRight,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFFFB700),
                          foregroundColor: Colors.white,  
                          padding: const EdgeInsets.symmetric(
                              horizontal: 32, vertical: 10),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18)),
                          textStyle: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        onPressed: () {
                          if (nameController.text.isEmpty ||
                              selectedKategori == null ||
                              selectedDate == null ||
                              selectedTime == null) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("Harap lengkapi semua field"),
                                backgroundColor: Colors.red,
                              ),
                            );
                            return;
                          }
                          setState(() {
                            portfolios.add({
                              "title": nameController.text,
                              "category": selectedKategori!,
                              "productCount": 1,
                              "value": 100000,
                              "profit": 0,
                              "icon": Icons.folder_open,
                            });
                          });
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text("Portofolio ditambahkan!"),
                              backgroundColor: Colors.green,
                            ),
                          );
                        },
                        child: const Text("Simpan"),
                      ),
                    )
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF6DF),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color(0xFFFFF6DF),
        title: const Text("Portofolio",
            style: TextStyle(
              color: Colors.black87,
              fontWeight: FontWeight.bold,
              fontFamily: 'Inter',
            )),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black12, blurRadius: 6, offset: Offset(0, 2))
              ],
            ),
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: Text(
                        "Nilai Portofolio",
                        style: TextStyle(
                            fontWeight: FontWeight.w600, fontFamily: 'Inter'),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFDE7D6),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: const [
                          Icon(Icons.pets, color: Colors.brown, size: 15),
                          SizedBox(width: 3),
                          Text(
                            "Konservatif",
                            style: TextStyle(
                                fontSize: 12,
                                color: Colors.brown,
                                fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center, 
                  children: [
                    const Text(
                      "Rp ",
                      style: TextStyle(
                        fontSize: 20, 
                        color: Colors.black87,
                        fontFamily: 'Inter',
                      ),
                    ),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      child: _showAmount
                          ? Text(
                              _moneyFormat(_portfolioValue),
                              style: const TextStyle(
                                fontSize: 28,
                                
                                color: Colors.black,
                                fontFamily: 'Inter',
                              ),
                            )
                          : Text(
                              "••••••",
                              key: const ValueKey('hidden'),
                              style: TextStyle(
                                fontSize: 28,
                                letterSpacing: 2,
                                fontWeight: FontWeight.bold,
                                color: Colors.black.withOpacity(0.7),
                                fontFamily: 'Inter',
                              ),
                            ),
                    ),
                    const SizedBox(width: 8),
                    InkWell(
                      onTap: () => setState(() => _showAmount = !_showAmount),
                      child: Icon(
                        _showAmount ? Icons.lock_open : Icons.lock_outline,
                        size: 22, 
                        color: Colors.black54,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                const Text("Rp0 (0.00%)",
                    style: TextStyle(fontSize: 12, color: Colors.grey)),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildPersentaseCircle(
                        "0%", "Pasar Uang", Colors.pink[100]!),
                    _buildPersentaseCircle(
                        "30%", "Obligasi", Colors.green[100]!),
                    _buildPersentaseCircle(
                        "15%", "Saham", Colors.orange[100]!),
                    _buildPersentaseCircle(
                        "55%", "Campuran", Colors.purple[100]!),
                  ],
                ),
                const SizedBox(height: 8),
                const Divider(),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 6,
                        margin: const EdgeInsets.only(right: 12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          color: Colors.orange[100],
                        ),
                        child: Stack(
                          children: [
                            FractionallySizedBox(
                              widthFactor: 0.5,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.orange,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Text(
                      "Monthly Streak",
                      style: TextStyle(fontSize: 13, color: Colors.black87),
                    ),
                    SizedBox(width: 10),
                    Row(
                      children: const [
                        Text("150",
                            style: TextStyle(
                                color: Colors.deepOrange,
                                fontWeight: FontWeight.bold)),
                        Icon(Icons.local_fire_department,
                            color: Colors.orange, size: 18),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              const Text(
                "Portofolio",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  fontFamily: 'Inter',
                ),
              ),
              const Spacer(),
              TextButton(
                onPressed: _showSheet,
                style: TextButton.styleFrom(
                  foregroundColor: const Color(0xFFFFB700),
                  textStyle: const TextStyle(fontWeight: FontWeight.bold),
                ),
                child: const Text("+ Tambah"),
              ),
            ],
          ),
          Row(
            children: [
              Checkbox(
                value: showActiveOnly,
                activeColor: const Color(0xFFFFB700),
                onChanged: (val) => setState(() => showActiveOnly = val!),
              ),
              const Text("Tampilkan hanya portofolio yang aktif"),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              ...["Pasar Uang", "Obligasi", "Saham"].map((label) {
                bool isActive = chipsSelected == label;
                return Container(
                  margin: const EdgeInsets.only(right: 10),
                  child: ChoiceChip(
                    label: Text(label,
                        style: TextStyle(
                            color: isActive
                                ? Colors.white
                                : const Color(0xFFFFB700))),
                    selected: isActive,
                    selectedColor: const Color(0xFFFFB700),
                    backgroundColor: Colors.white,
                    labelStyle: const TextStyle(fontWeight: FontWeight.w600),
                    onSelected: (_) => setState(() => chipsSelected = label),
                  ),
                );
              }),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.grey[300]!),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              children: [
                const Icon(Icons.search, color: Colors.grey),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    decoration: const InputDecoration(
                      hintText: "Cari Portofolio",
                      border: InputBorder.none,
                    ),
                    onChanged: (val) => setState(() {}),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Column(
            children: filteredPortfolios.map((p) => _buildPortfolioCard(p)).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildPersentaseCircle(String percent, String label, Color color) {
    return Column(
      children: [
        CircleAvatar(
          radius: 18,
          backgroundColor: color,
          child: Text(percent,
              style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 13)),
        ),
        const SizedBox(height: 2),
        Text(label,
            style: const TextStyle(fontSize: 11, color: Colors.black87)),
      ],
    );
  }

  Widget _buildPortfolioCard(Map<String, dynamic> p) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
              color: Colors.black12, blurRadius: 2, offset: Offset(0, 2))
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: const Color(0xFFFFB700),
            child: Icon(p["icon"], color: Colors.white),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  p["title"],
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 16),
                ),
                Text(
                  "${p["productCount"]} Produk",
                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                ),
                Text(
                  "Nilai Portofolio\n${_moneyFormat(p["value"])}",
                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Text("Keuntungan",
                  style: TextStyle(fontSize: 11, color: Colors.black54)),
              Text(_moneyFormat(p["profit"]),
                  style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                      fontSize: 14)),
            ],
          ),
        ],
      ),
    );
  }
}
