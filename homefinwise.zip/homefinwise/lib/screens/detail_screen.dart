import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../models/modul.dart';





class DetailScreen extends StatefulWidget {
  final Modul modul;
  const DetailScreen({required this.modul});

  @override
  _DetailScreenState createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  late VideoPlayerController _controller;
  double _currentVolume = 1.0;
  bool _showControls = true;
  bool showVolumeSlider = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset('assets/videos/videobelajar1.mp4')
      ..initialize().then((_) {
        setState(() {});
      });
    _controller.addListener(() {
      setState(() {});
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onPlayPause() {
    setState(() {
      _controller.value.isPlaying ? _controller.pause() : _controller.play();
      _showControls = true;
    });
  }

  void _onSeek(double value) {
    final position = Duration(seconds: value.round());
    _controller.seekTo(position);
    setState(() {
      _showControls = true;
    });
  }

  void _onVolumeChange(double value) {
    setState(() {
      _currentVolume = value;
      _controller.setVolume(value);
    });
  }

  String _formatDuration(Duration d) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = twoDigits(d.inMinutes.remainder(60));
    final seconds = twoDigits(d.inSeconds.remainder(60));
    return "$minutes:$seconds";
  }

  @override
  Widget build(BuildContext context) {
    final videoReady = _controller.value.isInitialized;
    final duration = videoReady ? _controller.value.duration : Duration.zero;
    final position = videoReady ? _controller.value.position : Duration.zero;
    final modul = widget.modul;

    return Scaffold(
      backgroundColor: const Color(0xFFFCF6FF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          'FINWISE ACADEMY',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // VIDEO PLAYER
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.all(8),
              child: AspectRatio(
                aspectRatio: videoReady ? _controller.value.aspectRatio : 16 / 9,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // VIDEO
                    videoReady
                        ? GestureDetector(
                            onTap: () {
                              setState(() {
                                _showControls = !_showControls;
                                showVolumeSlider = false;
                              });
                            },
                            child: VideoPlayer(_controller),
                          )
                        : const Center(child: CircularProgressIndicator()),
                    // PLAY/PAUSE BUTTON
                    if (videoReady && (_showControls || !_controller.value.isPlaying))
                      Center(
                        child: IconButton(
                          icon: Icon(
                            _controller.value.isPlaying
                                ? Icons.pause_circle_filled
                                : Icons.play_circle_filled,
                            size: 70,
                            color: Color(0xFFFFB700),
                          ),
                          onPressed: _onPlayPause,
                        ),
                      ),
                    // CONTROLS BOTTOM
                    if (videoReady && (_showControls || !_controller.value.isPlaying))
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 0,
                        child: Container(
                          padding: const EdgeInsets.only(left: 8, right: 8, bottom: 8, top: 8),
                          color: Colors.black.withOpacity(0.28),
                          child: Row(
                            children: [
                              // Durasi (kiri)
                              Text(
                                _formatDuration(position),
                                style: const TextStyle(fontSize: 12, color: Colors.white),
                              ),
                              // Slider video (panjang)
                              Expanded(
                                child: Slider(
                                  value: position.inSeconds.toDouble().clamp(0.0, duration.inSeconds.toDouble()),
                                  min: 0,
                                  max: duration.inSeconds.toDouble() > 0 ? duration.inSeconds.toDouble() : 1,
                                  activeColor: Color(0xFFFFB700),
                                  inactiveColor: Color(0xFFFFD773),
                                  onChanged: (value) => _onSeek(value),
                                ),
                              ),
                              // Durasi (kanan)
                              Text(
                                _formatDuration(duration),
                                style: const TextStyle(fontSize: 12, color: Colors.white),
                              ),
                              const SizedBox(width: 10),
                              // Icon speaker OR slider volume (toggle)
                              if (!showVolumeSlider)
                                GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      showVolumeSlider = true;
                                    });
                                  },
                                  child: const Icon(Icons.volume_up, color: Color(0xFFFFB700), size: 22),
                                )
                              else
                                SizedBox(
                                  width: 80,
                                  child: Slider(
                                    value: _currentVolume,
                                    min: 0,
                                    max: 1,
                                    activeColor: Color(0xFFFFB700),
                                    inactiveColor: Color(0xFFFFD773),
                                    onChanged: (value) => _onVolumeChange(value),
                                    onChangeEnd: (value) {
                                      setState(() {
                                        showVolumeSlider = false;
                                      });
                                    },
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            // INFO MODUL
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.grey[300]!),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    modul.title,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  if (modul.presenter != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      "Presented by ${modul.presenter!}",
                      style: const TextStyle(fontSize: 14, color: Colors.black87),
                    ),
                  ],
                  const Divider(),
                  const SizedBox(height: 8),
                  const Text(
                    "Apa yang Akan Kamu Pelajari",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  ...?modul.learningPoints?.map((point) => _buildBullet(point)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            // Next Chapter
            if ((modul.nextChapters != null && modul.nextChapters!.isNotEmpty))
              Column(
                
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Next Chapter",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  const Divider(thickness: 1),
                  ...modul.nextChapters!.map((next) => _nextChapterCard(
                        context,
                        image: next.image,
                        title: next.title,
                        chapter: next.chapter,
                        
                      )),
                ],
              ),
          ],
        ),
      ),
    );
  }

  static Widget _buildBullet(String text) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("• ", style: TextStyle(fontSize: 16)),
        Expanded(child: Text(text, style: TextStyle(fontSize: 15))),
      ],
    );
  }

  Widget _nextChapterCard(BuildContext context,
      {required String image, required String title, required String chapter}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.asset(
              image,
              width: 62,
              height: 62,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                Text(chapter, style: TextStyle(fontSize: 13, color: Colors.grey[700])),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
