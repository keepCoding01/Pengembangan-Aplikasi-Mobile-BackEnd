import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


class TopUpPage extends StatefulWidget {
  const TopUpPage({super.key});

  @override
  State<TopUpPage> createState() => _TopUpPageState();
}

class _TopUpPageState extends State<TopUpPage> {
  final TextEditingController _controller = TextEditingController();
  final int minTopUp = 100000;
  int? selectedNominal;
  bool isChecked = false;
  int totalPembayaran = 0;
  int tabIndex = 0;

  final List<int> presetNominal = [100000, 250000, 350000, 500000, 750000];
  final List<String> tabTitles = ['Prospektus', 'Ringkasan', 'Ketentuan'];

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onNominalChanged);
  }

  void _onNominalChanged() {
    String val = _controller.text.replaceAll('.', '');
    int? value = int.tryParse(val);
    setState(() {
      selectedNominal = null;
      if (value != null && value >= minTopUp) {
        totalPembayaran = value;
      } else {
        totalPembayaran = 0;
      }
    });
  }

  String formatCurrency(int number) {
    return NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0)
        .format(number);
  }

  void _onPresetTap(int value) {
    setState(() {
      selectedNominal = value;
      _controller.text = value.toString();
      totalPembayaran = value;
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _tabItem(String title, bool active, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: active ? const Color(0xFFFFB700) : Colors.transparent,
                width: 2,
              ),
            ),
          ),
          child: Text(
            title,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: active ? const Color(0xFFFFB700) : Colors.black54,
            ),
          ),
        ),
      ),
    );
  }

  void _showSuccessDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Icon(Icons.timelapse, size: 66, color: const Color(0xFFFFE082)),
                  Icon(Icons.check_circle_rounded, size: 60, color: Color(0xFFFFB700)),
                ],
              ),
              const SizedBox(height: 24),
              const Text(
                "Top Up Reksadana\nKamu Berhasil",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: Color(0xFFFFB700),
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context); // tutup dialog
                    Navigator.pop(context, totalPembayaran); // kirim nominal balik ke Home
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFFFFB700),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  child: const Text("Confirm"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Top Up Reksadana'),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        children: [
          // Card produk
          Container(
            margin: const EdgeInsets.only(top: 16, bottom: 8),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  backgroundColor: const Color(0xFFFFB700),
                  radius: 24,
                  child: const Icon(Icons.lock, color: Colors.white, size: 28),
                  
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'Pasar Uang',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, color: Color(0xFFFFB700)),
                      ),
                      SizedBox(height: 2),
                      Text(
                        'Insight Money',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 1),
                      Text(
                        'Insight Investment Management, PT',
                        style: TextStyle(fontSize: 12, color: Colors.black54),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Divider(thickness: 1.0, color: Color(0xFFFFB700)),
          Table(
            columnWidths: const {
              0: FlexColumnWidth(2),
              1: FlexColumnWidth(2.5),
            },
            children: const [
              TableRow(children: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 5),
                  child: Text('Harga/Unit (15 April 2025)'),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 5),
                  child: Text('Rp.1.807,85', textAlign: TextAlign.right),
                ),
              ]),
              TableRow(children: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 5),
                  child: Text('Min. Pembelian Pertama'),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 5),
                  child: Text('Rp.100.000', textAlign: TextAlign.right),
                ),
              ]),
              TableRow(children: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 5),
                  child: Text('Min. Topup'),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 5),
                  child: Text('Rp.100.000', textAlign: TextAlign.right),
                ),
              ]),
              TableRow(children: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 5),
                  child: Text('Biaya Pembelian'),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 5),
                  child: Text('Gratis',
                      textAlign: TextAlign.right,
                      style: TextStyle(color: Color(0xFFFFB700), fontWeight: FontWeight.bold)),
                ),
              ]),
              TableRow(children: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 5),
                  child: Text('Biaya Admin'),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 5),
                  child: Text('Rp0', textAlign: TextAlign.right),
                ),
              ]),
            ],
          ),
          const SizedBox(height: 24),
          const Text(
            'Jumlah Pembelian',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text(
                "Rp",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
              const SizedBox(width: 5),
              Expanded(
                child: TextField(
                  controller: _controller,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    hintText: 'Min. 100.000',
                    hintStyle: const TextStyle(color: Colors.grey),
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 8, horizontal: 8),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.amber.shade700),
                    ),
                  ),
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  onChanged: (value) {
                    String newValue = value.replaceAll('.', '');
                    if (newValue.isEmpty) return;
                    final int? intValue = int.tryParse(newValue);
                    if (intValue != null) {
                      _controller.value = TextEditingValue(
                        text: NumberFormat.decimalPattern('id_ID').format(intValue),
                        selection: TextSelection.collapsed(
                            offset: NumberFormat.decimalPattern('id_ID').format(intValue).length),
                      );
                    }
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: presetNominal.map((e) {
                bool active = selectedNominal == e;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: OutlinedButton(
                    onPressed: () => _onPresetTap(e),
                    style: OutlinedButton.styleFrom(
                      backgroundColor: active ? const Color(0xFFFFB700) : Colors.white,
                      side: BorderSide(
                        color: active ? const Color(0xFFFFB700) : Colors.grey.shade300,
                        width: 2,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: Text(
                      NumberFormat.decimalPattern('id_ID').format(e),
                      style: TextStyle(
                          color: active ? Colors.white : Colors.black87,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 24),
          Row(
            children: List.generate(3, (i) => _tabItem(tabTitles[i], tabIndex == i, () {
              setState(() { tabIndex = i; });
            })),
          ),
          const SizedBox(height: 16),
          if (tabIndex == 0)
            const Text("Ini halaman Prospektus."),
          if (tabIndex == 1)
            const Text("Ini halaman Ringkasan."),
          if (tabIndex == 2)
            const Text("Ini halaman Ketentuan."),
          const SizedBox(height: 20),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Checkbox(
                value: isChecked,
                activeColor: const Color(0xFFFFB700),
                onChanged: (val) {
                  setState(() {
                    isChecked = val ?? false;
                  });
                },
              ),
              const Expanded(
                child: Text(
                  "Saya telah membaca dan menyetujui seluruh Prospektus dan keterangan ringkas serta memahami resiko atas keputusan investasi yang akan saya buat",
                  style: TextStyle(fontSize: 13),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text("Total Pembayaran", style: TextStyle(fontSize: 16)),
              Text(
                totalPembayaran > 0
                    ? formatCurrency(totalPembayaran)
                    : 'Rp 0',
                style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: Colors.black),
              ),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: (isChecked && totalPembayaran >= minTopUp)
                  ? () {
                      _showSuccessDialog(context);
                    }
                  : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFB700),
                disabledBackgroundColor: Colors.amber.shade100,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                padding: const EdgeInsets.symmetric(vertical: 16),
                textStyle: const TextStyle(fontWeight: FontWeight.bold),
              ),
              child: const Text("Order Sekarang"),
            ),
          ),
          const SizedBox(height: 32),
        ],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.only(bottom: 12, top: 4),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 8,
              offset: const Offset(0, -1),
            )
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: const [
            Icon(Icons.home, size: 30, color: Color(0xFFFFB700)),
            Icon(Icons.pie_chart_rounded, size: 30, color: Colors.grey),
            Icon(Icons.search, size: 30, color: Colors.grey),
            Icon(Icons.library_books, size: 30, color: Colors.grey),
            Icon(Icons.person, size: 30, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}
