import 'dart:async';
import 'package:flutter/material.dart';
import 'package:homefinwise/screens/register_page.dart';


class CoverPage extends StatefulWidget {
  const CoverPage({super.key});

  @override
  State<CoverPage> createState() => _CoverPageState();
}

class _CoverPageState extends State<CoverPage> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 5), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const RegisterPage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: const Color(0xFFFDC434), 
      body: Stack(
        children: [
          // Ornamen bulat atas
          Positioned(
            top: -size.width * 0.42,
            left: -size.width * 0.24,
            child: Container(
              width: size.width * 1.2,
              height: size.width * 1.2,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFFFFDB80), // Ornamen 1
              ),
            ),
          ),
          // Ornamen bulat bawah
          Positioned(
            bottom: -size.width * 0.35,
            right: -size.width * 0.15,
            child: Container(
              width: size.width * 1.1,
              height: size.width * 1.1,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFFFFE297), // Ornamen 2
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Spacer biar agak ke atas sedikit
                  const SizedBox(height: 32),
                  // Teks judul
                  const Text(
                    'FINWISE',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.bold,
                      fontSize: 28,
                      color: Colors.black,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'SUPER INVESTASI SOBAT MUDA | 2025',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: Colors.black,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 44),
                  // Maskot gambar
                  Image.asset(
                    'assets/mascot.png', // Pastikan file sudah ada di folder assets
                    width: size.width * 0.62,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
