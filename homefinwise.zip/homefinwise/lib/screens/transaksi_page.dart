import 'package:flutter/material.dart';


class TransaksiPage extends StatefulWidget {
  const TransaksiPage({Key? key}) : super(key: key);

  @override
  State<TransaksiPage> createState() => _TransaksiPageState();
}

class _TransaksiPageState extends State<TransaksiPage> with SingleTickerProviderStateMixin {
  int selectedTab = 0;
  bool isFabExpanded = false;
  late AnimationController _controller;
  DateTime? pickedOrderDate;
  DateTime? pickedHistoryDate;

  List<Map<String, dynamic>> daftarOrder = [
    {
      'title': 'Reksa Dana Saham',
      'date': '2025-06-28',
      'nominal': 500000,
      'status': 'Selesai'
    },
    {
      'title': 'Reksa Dana Campuran',
      'date': '2025-06-25',
      'nominal': 300000,
      'status': 'Selesai'
    },
    {
      'title': 'Reksa Dana Pasar Uang',
      'date': '2025-06-20',
      'nominal': 100000,
      'status': 'Selesai'
    },
  ];

  final List<Map<String, dynamic>> riwayat = [
    {
      'title': 'Reksa Dana Pasar Uang',
      'date': '2024-07-16',
      'nominal': 60750,
      'status': 'Order Jual Berhasil',
      'statusColor': Colors.green
    },
    {
      'title': 'Reksa Dana Pasar Uang',
      'date': '2024-05-07',
      'nominal': 10000,
      'status': 'Pembelian Berhasil',
      'statusColor': Colors.green
    },
    {
      'title': 'Reksa Dana Saham',
      'date': '2024-04-08',
      'nominal': 10000,
      'status': 'Pembelian Berhasil',
      'statusColor': Colors.green
    },
    {
      'title': 'Reksa Dana Campuran',
      'date': '2024-06-22',
      'nominal': 100000,
      'status': 'Pembelian Berhasil',
      'statusColor': Colors.green
    },
  ];

  @override
  void initState() {
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void toggleFab() {
    setState(() {
      isFabExpanded = !isFabExpanded;
      if (isFabExpanded) {
        _controller.forward();
      } else {
        _controller.reverse();
      }
    });
  }

  void addOrder(String produk, int nominal) {
    setState(() {
      daftarOrder.insert(
        0,
        {
          'title': produk,
          'date': DateTime.now().toString().split(' ')[0],
          'nominal': nominal,
          'status': 'Menunggu Pembayaran'
        },
      );
      isFabExpanded = false; // Balikin FAB ke hamburger
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$produk berhasil ditambahkan ke order!'),
        backgroundColor: Colors.orange,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void showNominalDialog(String produk) {
    TextEditingController nominalController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        backgroundColor: const Color(0xFFF7F1FA),
        title: const Text('Masukkan Nominal'),
        content: TextField(
          controller: nominalController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            hintText: "Contoh: 100000",
            border: UnderlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Batal", style: TextStyle(color: Color(0xFFFFB700))),
          ),
          TextButton(
            onPressed: () {
              int? nominal = int.tryParse(nominalController.text);
              if (nominal != null && nominal > 0) {
                addOrder(produk, nominal);
                Navigator.pop(ctx);
              }
            },
            child: const Text("Tambah", style: TextStyle(color: Color(0xFFFFB700))),
          ),
        ],
      ),
    );
  }

  // ===== DATE PICKER =====
  Future<void> pickOrderDate() async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: pickedOrderDate ?? DateTime.now(),
      firstDate: DateTime(2022),
      lastDate: DateTime(2030),
    );
    setState(() => pickedOrderDate = picked);
  }
  Future<void> pickHistoryDate() async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: pickedHistoryDate ?? DateTime.now(),
      firstDate: DateTime(2022),
      lastDate: DateTime(2030),
    );
    setState(() => pickedHistoryDate = picked);
  }

  List<Map<String, dynamic>> get filteredOrders {
    if (pickedOrderDate == null) return daftarOrder;
    String filterDate = "${pickedOrderDate!.year.toString().padLeft(4, '0')}-${pickedOrderDate!.month.toString().padLeft(2, '0')}-${pickedOrderDate!.day.toString().padLeft(2, '0')}";
    return daftarOrder.where((order) => order['date'] == filterDate).toList();
  }
  List<Map<String, dynamic>> get filteredRiwayat {
    if (pickedHistoryDate == null) return riwayat;
    String filterDate = "${pickedHistoryDate!.year.toString().padLeft(4, '0')}-${pickedHistoryDate!.month.toString().padLeft(2, '0')}-${pickedHistoryDate!.day.toString().padLeft(2, '0')}";
    return riwayat.where((order) => order['date'] == filterDate).toList();
  }

  @override
  Widget build(BuildContext context) {
    Color mainColor = Colors.orange;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: const Text(
          "Transaksi",
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 22, color: Colors.black),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          child: Container(
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Colors.black12, width: 1),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => selectedTab = 0),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      decoration: BoxDecoration(
                        border: selectedTab == 0
                            ? Border(
                                bottom: BorderSide(
                                    color: mainColor, width: 2))
                            : null,
                      ),
                      child: Text(
                        "Order",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: selectedTab == 0 ? mainColor : Colors.black38,
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => selectedTab = 1),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      decoration: BoxDecoration(
                        border: selectedTab == 1
                            ? Border(
                                bottom: BorderSide(
                                    color: mainColor, width: 2))
                            : null,
                      ),
                      child: Text(
                        "History",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: selectedTab == 1 ? mainColor : Colors.black38,
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(14.0),
        child: selectedTab == 0 ? _buildOrderTab() : _buildHistoryTab(),
      ),
      floatingActionButton: selectedTab == 0 ? _buildFabMenu() : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      backgroundColor: const Color(0xFFF8F5FC),
    );
  }

  Widget _buildOrderTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              "Daftar Order",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Inter'),
            ),
            IconButton(
              icon: const Icon(Icons.date_range, color:Color(0xFFFFB700)),
              onPressed: pickOrderDate,
            ),
          ],
        ),
        const Divider(thickness: 1),
        Expanded(
          child: ListView.builder(
            itemCount: filteredOrders.length,
            itemBuilder: (context, i) {
              var order = filteredOrders[i];
              return Card(
                color: const Color(0xFFF5F1FA),
                elevation: 4,
                shadowColor: Colors.black26,
                margin: const EdgeInsets.only(bottom: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16), // padding cukup
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(order['title'],
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 16)),
                            const SizedBox(height: 2),
                            Text("Tanggal: ${order['date']}", style: const TextStyle(fontSize: 13, color: Colors.black87)),
                            Text("Nominal: Rp${order['nominal']}", style: const TextStyle(fontSize: 13, color: Colors.black87)),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (order['status'] == 'Selesai')
                            const Text("Selesai",
                                style: TextStyle(
                                    color:Color(0xFFFFB700),
                                    fontWeight: FontWeight.w600,
                                    fontSize: 13)),
                          if (order['status'] == 'Menunggu Pembayaran') ...[
                            const Text("Menunggu Pembayaran",
                                style: TextStyle(
                                    color:Color(0xFFFFB700),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500)),
                            const SizedBox(height: 6),
                            ElevatedButton(
                              onPressed: () {},
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFFFDB80),
                                foregroundColor: Colors.white,
                                elevation: 0,
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 0),
                                minimumSize: const Size(110, 33),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16)),
                              ),
                              child: const Text("Bayar Sekarang", style: TextStyle(fontSize: 13)),
                            ),
                          ],
                        ],
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildHistoryTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              "Riwayat Transaksi",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Inter'),
            ),
            IconButton(
              icon: const Icon(Icons.date_range, color: Color(0xFFFFB700)),
              onPressed: pickHistoryDate,
            ),
          ],
        ),
        const Divider(thickness: 1),
        Expanded(
          child: ListView.builder(
            itemCount: filteredRiwayat.length,
            itemBuilder: (context, i) {
              var trx = filteredRiwayat[i];
              return Card(
                color: const Color(0xFFF5F1FA),
                elevation: 4,
                shadowColor: Colors.black26,
                margin: const EdgeInsets.only(bottom: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(trx['title'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 4),
                      Text(trx['date'], style: const TextStyle(fontSize: 13)),
                      const SizedBox(height: 8),
                      Text("Rp${trx['nominal']}", style: const TextStyle(color: Colors.orange, fontWeight: FontWeight.bold, fontSize: 17)),
                      const SizedBox(height: 4),
                      Text(trx['status'], style: TextStyle(color: trx['statusColor'], fontSize: 13)),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildFabMenu() {
    return Stack(
      children: [
        if (isFabExpanded)
          GestureDetector(
            onTap: toggleFab,
            child: Container(
              color: Colors.black.withOpacity(0.15),
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
            ),
          ),
        Positioned(
          bottom: 18,
          right: 18,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (isFabExpanded) ...[
                FloatingActionButton.extended(
                  heroTag: 'fab1',
                  onPressed: () => showNominalDialog('Reksa Dana Pasar Uang'),
                  icon: const Icon(Icons.trending_up),
                  label: const Text('Pasar Uang'),
                  foregroundColor: Colors.white,
                  backgroundColor: Colors.orange.shade400,
                ),
                const SizedBox(height: 12),
                FloatingActionButton.extended(
                  heroTag: 'fab2',
                  onPressed: () => showNominalDialog('Reksa Dana Saham'),
                  icon: const Icon(Icons.auto_graph),
                  label: const Text('Saham'),
                  backgroundColor: Colors.orange.shade400,
                  foregroundColor: Colors.white,
                ),
                const SizedBox(height: 12),
                FloatingActionButton.extended(
                  heroTag: 'fab3',
                  onPressed: () => showNominalDialog('Reksa Dana Campuran'),
                  icon: const Icon(Icons.stacked_bar_chart),
                  label: const Text('Campuran'),
                  backgroundColor: Colors.orange.shade400,
                  foregroundColor: Colors.white,
                ),
                const SizedBox(height: 12),
              ],
              FloatingActionButton(
                heroTag: 'fabMain',
                backgroundColor: Colors.orange,
                onPressed: toggleFab,
                child: Icon(
                  isFabExpanded ? Icons.close : Icons.menu,
                  size: 30,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
