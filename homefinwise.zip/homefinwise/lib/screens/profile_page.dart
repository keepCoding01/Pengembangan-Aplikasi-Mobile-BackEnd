import '../theme_notifier.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:provider/provider.dart'; 


class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String _nama = "Rasid";
  String _gender = "Laki-laki";
  String _kategori = "Investor Pemula";
  List<String> _interests = ["Saham"];
  File? _profileImageFile;
  String? _profileImagePath;

  final TextEditingController namaController = TextEditingController();
  String selectedGender = "Laki-laki";
  String selectedCategory = "Investor Pemula";
  List<String> selectedMinat = ["Saham"];
  File? tempImage;
  final List<String> minatList = ["Saham", "Reksa Dana", "Obligasi"];

  double sliderValue = 1.0;
  bool isSyariah = false;
  DateTime? _selectedCalendarDate;
  int profileTab = 0;

  @override
  void initState() {
    super.initState();
    _loadProfileImagePath();
  }

  @override
  void dispose() {
    namaController.dispose();
    super.dispose();
  }

  void _loadProfileImagePath() async {
    final prefs = await SharedPreferences.getInstance();
    String? path = prefs.getString('profile_image_path');
    if (path != null && path.isNotEmpty && File(path).existsSync()) {
  _profileImageFile = File(path);
}

  }

  Future<void> _saveProfileImagePath(String path) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('profile_image_path', path);
  }

  Future<File?> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      await _saveProfileImagePath(picked.path);
      setState(() {
        _profileImagePath = picked.path;
        _profileImageFile = File(picked.path);
      });
      return File(picked.path);
    }
    return null;
  }

  Color getSurfaceColor(BuildContext context) {
    final isDark = Provider.of<ThemeNotifier>(context).isDark;
    return isDark ? const Color(0xFF232323) : Colors.white;
  }

  ImageProvider get profileImage {
    if (_profileImageFile != null && _profileImageFile!.existsSync()) {
      return FileImage(_profileImageFile!);
    }
    return const AssetImage("assets/xyidd.jpg");
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showTentangSayaDialog() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.25),
      builder: (context) => Dialog(
        backgroundColor: const Color(0xFFFDF2E6),
        insetPadding: const EdgeInsets.symmetric(horizontal: 30, vertical: 32),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                "Tentang Saya",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 21),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              Center(
                child: CircleAvatar(
                  radius: 38,
                  backgroundImage: profileImage,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                "Nama: $_nama\nJenis Kelamin: $_gender\nKategori: $_kategori\nMinat: ${_interests.isNotEmpty ? _interests.join(', ') : '-'}",
                style: const TextStyle(fontSize: 15),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 22),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text("Tutup", style: TextStyle(color: Colors.brown, fontWeight: FontWeight.w600)),
                  ),
                  const Spacer(),
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _showSnackBar("Berhasil dibagikan!");
                    },
                    child: const Text(
                      "Bagikan Sekarang",
                      style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showEditProfileSheet() {
    namaController.text = _nama;
    selectedGender = _gender;
    selectedCategory = _kategori;
    selectedMinat = [..._interests];
    tempImage = _profileImageFile;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => AnimatedPadding(
        padding: MediaQuery.of(context).viewInsets +
            const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
        child: StatefulBuilder(
          builder: (context, setStateModal) => SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  height: 2,
                  width: 40,
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                const Text(
                  "Edit Profil",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    CircleAvatar(
                      radius: 36,
                      backgroundImage: tempImage != null
                          ? FileImage(tempImage!)
                          : const AssetImage("assets/xyidd.jpg") as ImageProvider,
                    ),
                    Positioned(
                      right: 2,
                      bottom: 2,
                      child: Material(
                        color: Colors.orange,
                        shape: const CircleBorder(),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: () async {
                            File? picked = await ImagePicker().pickImage(source: ImageSource.gallery).then((xfile) => xfile != null ? File(xfile.path) : null);
                            setStateModal(() {
                              tempImage = picked;
                            });
                                                    },
                          child: const Padding(
                            padding: EdgeInsets.all(7.0),
                            child: Icon(Icons.edit, color: Colors.white, size: 19),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: namaController,
                  decoration: const InputDecoration(
                    labelText: "Nama Lengkap",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text("Jenis Kelamin:"),
                ),
                Row(
                  children: [
                    Radio<String>(
                      value: 'Perempuan',
                      groupValue: selectedGender,
                      onChanged: (value) {
                        setStateModal(() => selectedGender = value!);
                      },
                    ),
                    const Text('Perempuan'),
                    Radio<String>(
                      value: 'Laki-laki',
                      groupValue: selectedGender,
                      onChanged: (value) {
                        setStateModal(() => selectedGender = value!);
                      },
                    ),
                    const Text('Laki-laki'),
                  ],
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  children: minatList.map((interest) {
                    return FilterChip(
                      label: Text(interest),
                      selected: selectedMinat.contains(interest),
                      onSelected: (selected) {
                        setStateModal(() {
                          if (selected) {
                            selectedMinat.add(interest);
                          } else {
                            selectedMinat.remove(interest);
                          }
                        });
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: selectedCategory,
                  decoration: const InputDecoration(
                    labelText: "Kategori",
                    border: OutlineInputBorder(),
                  ),
                  items: [
                    'Investor Pemula',
                    'Investor Mahir',
                    'Investor Profesional'
                  ].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                  onChanged: (value) {
                    setStateModal(() => selectedCategory = value!);
                  },
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange),
                  onPressed: () async {
                    setState(() {
                      _nama = namaController.text.isEmpty ? "Rasid" : namaController.text;
                      _gender = selectedGender;
                      _kategori = selectedCategory;
                      _interests = [...selectedMinat];
                      _profileImageFile = tempImage;
                    });
                    if (tempImage != null) {
                      await _saveProfileImagePath(tempImage!.path);
                    }
                    Navigator.pop(context);
                  },
                  child: const Text("Simpan", style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _launchWebBibit() async {
    _showSnackBar('Web Bibit dibuka!');
   
  }

  Widget _menuItem(
    String title,
    IconData icon, {
    Widget? trailing,
    VoidCallback? onTap,
    bool hideChevron = false,
    String? subtitle,
    Color? subtitleColor,
    Color? color,
  }) {
    final isDark = Provider.of<ThemeNotifier>(context).isDark;

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 10),
      leading: Icon(
        icon,
        color: color ?? (isDark ? Colors.white70 : Colors.black54),
      ),
      title: Text(
        title,
        style: TextStyle(
          fontWeight: FontWeight.w500,
          fontSize: 15,
          color: isDark ? Colors.white : Colors.black,
        ),
      ),
      subtitle: subtitle != null
          ? Text(
              subtitle,
              style: TextStyle(
                color: subtitleColor ?? (isDark ? Colors.green[300] : Colors.green),
                fontWeight: FontWeight.w600,
              ),
            )
          : null,
      trailing: trailing ?? (hideChevron
          ? null
          : Icon(Icons.chevron_right_rounded,
              color: isDark ? Colors.white38 : Colors.black26)),
      onTap: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    // Pakai global theme
    final themeNotifier = Provider.of<ThemeNotifier>(context);
    final isDark = themeNotifier.isDark;
    final textColor = isDark ? Colors.white : Colors.black;
    final subTextColor = isDark ? Colors.green[300]! : Colors.green;

    return Scaffold(
      backgroundColor: isDark ? const Color(0xFF232323) : Colors.white,
      drawer: Drawer(
        backgroundColor: getSurfaceColor(context),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF222222) : const Color(0xFFFFE08A),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 25,
                    backgroundImage: profileImage,
                  ),
                  const SizedBox(height: 10),
                  Text(_nama,
                      style: TextStyle(
                        color: isDark ? Colors.white : Colors.black87,
                        fontSize: 18,
                      )),
                  Text(_kategori, style: const TextStyle(color: Colors.green)),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.person, color: isDark ? Colors.white : Colors.black54),
              title: const Text('Tentang Saya'),
              onTap: _showTentangSayaDialog,
            ),
            ListTile(
              leading: Icon(Icons.settings, color: isDark ? Colors.white : Colors.black54),
              title: const Text('Pengaturan'),
              onTap: () {
                _showSnackBar('Fitur pengaturan coming soon!');
              },
            ),
            ListTile(
              leading: Icon(Icons.language, color: isDark ? Colors.white : Colors.black54),
              title: const Text('Kunjungi Website Bibit'),
              onTap: _launchWebBibit,
            ),
            ListTile(
              leading: Icon(Icons.chat_bubble_outline, color: isDark ? Colors.white : Colors.black54),
              title: const Text('Chat Support'),
              onTap: _launchWebBibit,
            ),
          ],
        ),
      ),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: isDark ? const Color(0xFF303030) : const Color(0xFFFFDB80),
        title: Text(
          "Profil",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: textColor,
            fontSize: 22,
          ),
        ),
        centerTitle: true,
        leading: Builder(
          builder: (context) => IconButton(
            icon: Icon(Icons.menu, color: textColor),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
      ),
      body: ListView(
        children: [
          Container(
            color: isDark ? const Color(0xFF232323) : const Color(0xFFFFDB80),
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 32,
                      backgroundImage: profileImage,
                    ),
                    const SizedBox(width: 15),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _nama,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                              color: textColor),
                        ),
                        Text(
                          _kategori,
                          style: TextStyle(
                            fontSize: 14,
                            color: subTextColor,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                DefaultTabController(
                  length: 2,
                  initialIndex: profileTab,
                  child: Container(
                    color: isDark ? const Color(0xFF232323) : const Color(0xFFFFDB80),
                    child: TabBar(
                      onTap: (index) {
                        setState(() => profileTab = index);
                        if (index == 1) {
                          showDialog(
                            context: context,
                            barrierColor: Colors.black.withOpacity(0.3),
                            builder: (ctx) => Dialog(
                              backgroundColor: const Color(0xFFFDF2E6),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(22)),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Text(
                                      "Bagikan Profil",
                                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 21),
                                      textAlign: TextAlign.center,
                                    ),
                                    const SizedBox(height: 12),
                                    Center(
                                      child: CircleAvatar(
                                        radius: 28,
                                        backgroundImage: profileImage,
                                      ),
                                    ),
                                    const SizedBox(height: 12),
                                    const Text(
                                      "Bagikan Sekarang ke sosial media atau kontak Anda.",
                                      style: TextStyle(fontSize: 15),
                                      textAlign: TextAlign.center,
                                    ),
                                    const SizedBox(height: 22),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        TextButton(
                                          onPressed: () => Navigator.pop(ctx),
                                          child: const Text("Tutup",
                                              style: TextStyle(
                                                  color: Colors.brown,
                                                  fontWeight: FontWeight.w600)),
                                        ),
                                        const Spacer(),
                                        TextButton(
                                          onPressed: () {
                                            Navigator.pop(ctx);
                                            _showSnackBar("Berhasil dibagikan!");
                                          },
                                          child: const Text(
                                            "Bagikan Sekarang",
                                            style: TextStyle(
                                                color: Colors.orange,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        }
                      },
                      indicatorColor: Colors.orange,
                      indicatorWeight: 3,
                      labelColor: Colors.orange,
                      unselectedLabelColor: isDark ? Colors.white54 : Colors.black54,
                      labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      tabs: const [
                        Tab(text: 'Profil'),
                        Tab(text: 'Bagikan'),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 18),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 100,
                        child: Card(
                          elevation: 4,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          color: Colors.white,
                          child: InkWell(
                            borderRadius: BorderRadius.circular(16),
                            onTap: () async {
                              DateTime? picked = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(2000),
                                lastDate: DateTime(2100),
                              );
                              setState(() {
                                _selectedCalendarDate = picked;
                              });
                                                        },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFFFF3E0),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: const Icon(Icons.calendar_today_rounded, color: Colors.orange),
                                  ),
                                  const SizedBox(width: 10),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const Text("Kalender", style: TextStyle(fontWeight: FontWeight.bold)),
                                      if (_selectedCalendarDate != null)
                                        Text(
                                          "${_selectedCalendarDate!.day.toString().padLeft(2, '0')}/"
                                          "${_selectedCalendarDate!.month.toString().padLeft(2, '0')}/"
                                          "${_selectedCalendarDate!.year}",
                                          style: const TextStyle(color: Colors.grey, fontSize: 12),
                                        ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: SizedBox(
                        height: 100,
                        child: Card(
                          elevation: 4,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), color: Colors.white,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFE8F5E9),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Icon(Icons.show_chart_rounded, color: Colors.green),
                                ),
                                const SizedBox(width: 10),
                                const Text("Saham harian", style: TextStyle(fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 100,
                        child: Card(
                          elevation: 4,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          color: Colors.white,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFFFF3E0),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Icon(Icons.wallet, color: Colors.orange),
                                ),
                                const SizedBox(width: 10),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const Text("Rp50", style: TextStyle(fontWeight: FontWeight.bold)),
                                    const Text("Saldo Treding", style: TextStyle(color: Colors.grey, fontSize: 12)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: SizedBox(
                        height: 100,
                        child: Card(
                          elevation: 4,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          color: Colors.white,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFE8F5E9),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Icon(Icons.account_balance, color: Colors.green),
                                ),
                                const SizedBox(width: 10),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const Text("Rp50.000", style: TextStyle(fontWeight: FontWeight.bold)),
                                    const Text("Saldo Bank Jago", style: TextStyle(color: Colors.grey, fontSize: 12)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            color: getSurfaceColor(context),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text("Keamanan",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: isDark ? Colors.white : Colors.black)),
                    const Spacer(),
                  ],
                ),
                Slider(
                  value: sliderValue,
                  min: 0,
                  max: 2,
                  divisions: 2,
                  onChanged: (val) {
                    setState(() => sliderValue = val);
                  },
                  activeColor: const Color(0xFFFFB700),
                  inactiveColor: const Color(0xFFFFDB80),
                  label: '',
                ),
                Text(
                  "${sliderValue.toInt()} dari 2 fitur keamanan telah aktif",
                  style: TextStyle(
                    color: isDark ? Colors.white60 : Colors.black54,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 5),
              ],
            ),
          ),
          Container(
            color: getSurfaceColor(context),
            child: Column(
              children: [
                _menuItem("E-Statement", Icons.description_outlined),
                _menuItem("Bibit Syariah", Icons.mosque_outlined),
                _menuItem("Dark Mode", Icons.dark_mode_outlined,
                  trailing: Switch(
                    value: isDark,
                    onChanged: (val) {
                      themeNotifier.setDark(val);
                    },
                    activeColor: Colors.orange,
                  ),
                  hideChevron: true,
                ),
                _menuItem("Bibit untuk perusahaan", Icons.business_center_outlined,
                  subtitle: "Buat Akun Bisnis", subtitleColor: subTextColor,
                ),
                _menuItem("Cashback & Referral", Icons.card_giftcard_outlined),
                _menuItem("Promo & Voucher", Icons.discount_outlined, onTap: () => _showSnackBar('Promo akan segera hadir!')),
                _menuItem("Systematic Investment Plan (SIP)", Icons.repeat_on_outlined),
                _menuItem("Gift Card", Icons.card_membership_outlined),
                _menuItem("FinWise Academy", Icons.school_outlined),
                _menuItem("FAQs", Icons.help_outline),
                _menuItem("Kamus Investasi", Icons.menu_book_outlined),
                _menuItem("Komunitas", Icons.people_outline),
                const Divider(height: 32, thickness: 1),
                ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 10),
                  leading: const Icon(Icons.logout, color: Colors.red),
                  title: const Text(
                    "Log Out",
                    style: TextStyle(color: Colors.red),
                  ),
                  onTap: () {},
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                Text(
                  "PT FinWise Sinar Bersama\nberizin dan diawasi oleh",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    color: isDark ? Colors.white54 : Colors.grey,
                  ),
                ),
                Text(
                  "Otoritas Jasa Keuangan",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: isDark ? Colors.white70 : Colors.black54,
                    fontSize: 13,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          const SizedBox(height: 60),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.orange,
        child: const Icon(Icons.edit, color: Colors.white),
        onPressed: _showEditProfileSheet,
      ),
    );
  }
}
