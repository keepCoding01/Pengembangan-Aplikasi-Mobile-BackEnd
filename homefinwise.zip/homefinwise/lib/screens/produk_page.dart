import 'package:flutter/material.dart';
import 'topup_page.dart';


class ProdukPage extends StatefulWidget {
  final String produkTitle;
  const ProdukPage({Key? key, required this.produkTitle}) : super(key: key);

  @override
  State<ProdukPage> createState() => _ProdukPageState();
}

class _ProdukPageState extends State<ProdukPage> {
  bool filterSyariah = false;
  bool filterBaru = false;
  bool filterTerbatas = false;
  bool filterDividen = false;
  bool filterAutodebet = false;

  String selectedSort = 'Imbal Hasil Tertinggi';
  String selectedPeriode = '1 Tahun';

  final List<Map<String, dynamic>> allProduk = [
    {
      "logo": "assets/ic_reksadana.png",
      "name": "Insight Money",
      "manager": "Insight Investment Management, PT",
      "imbal": 6.12,
      "harga": 1807.85,
      "kelolaan": 980,
      "syariah": false,
      "baru": false,
      "terbatas": false,
      "dividen": false,
      "autodebet": false,
      "periode": "1 Tahun",
    },
    {
      "logo": "assets/ic_reksadana.png",
      "name": "Insight Money Syariah",
      "manager": "Insight Investment Management, PT",
      "imbal": 5.08,
      "harga": 1907.02,
      "kelolaan": 850,
      "syariah": true,
      "baru": true,
      "terbatas": false,
      "dividen": true,
      "autodebet": true,
      "periode": "1 Tahun",
    },
    {
      "logo": "assets/ic_reksadana.png",
      "name": "Capital Money Market Fund",
      "manager": "Capital Asset Management, PT",
      "imbal": 4.56,
      "harga": 1305.03,
      "kelolaan": 765,
      "syariah": false,
      "baru": false,
      "terbatas": true,
      "dividen": false,
      "autodebet": false,
      "periode": "1 Tahun",
    },
    {
      "logo": "assets/ic_reksadana.png",
      "name": "Syariah Dana Terbatas",
      "manager": "Mandiri Investasi, PT",
      "imbal": 7.21,
      "harga": 2500.11,
      "kelolaan": 1500,
      "syariah": true,
      "baru": false,
      "terbatas": true,
      "dividen": false,
      "autodebet": true,
      "periode": "1 Tahun",
    },
    // tambah data lain jika mau
  ];

  // ======== UI START ========
  @override
  Widget build(BuildContext context) {
    double margin = 22.0;

    // 1. FILTER produkList SESUAI FILTER/SORT
    List<Map<String, dynamic>> produkList = allProduk.where((p) {
      if (filterSyariah && !p["syariah"]) return false;
      if (filterBaru && !p["baru"]) return false;
      if (filterTerbatas && !p["terbatas"]) return false;
      if (filterDividen && !p["dividen"]) return false;
      if (filterAutodebet && !p["autodebet"]) return false;
      if (selectedPeriode != '1 Tahun' && (p["periode"] ?? '1 Tahun') != selectedPeriode) return false;
      return true;
    }).toList();

    // 2. SORTING
    if (selectedSort == "Imbal Hasil Tertinggi") {
      produkList.sort((a, b) => (b["imbal"] as double).compareTo(a["imbal"] as double));
    } else if (selectedSort == "Dana Kelolaan Tertinggi") {
      produkList.sort((a, b) => (b["kelolaan"] as int).compareTo(a["kelolaan"] as int));
    } else if (selectedSort == "Nama A-Z") {
      produkList.sort((a, b) => (a["name"] as String).compareTo(b["name"] as String));
    } else if (selectedSort == "Barometer Tertinggi") {
      // Sementara, sama dengan imbal hasil
      produkList.sort((a, b) => (b["imbal"] as double).compareTo(a["imbal"] as double));
    }

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            // --------- HEADER & APPBAR ----------
            
            Container(
              height: 68,
              color: Color(0xFFFFF1C1),
              padding: EdgeInsets.symmetric(horizontal: margin),
              child: Row(
                
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back, color: Colors.black, size: 26),
                    onPressed: () => Navigator.of(context).pop(),
                    splashRadius: 22,
                  ),
                  Expanded(
                    
                    child: Center(
                      child: Text(
                        "Produk ${widget.produkTitle}",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 22,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                  Opacity(
                    opacity: 0,
                    child: IconButton(
                      icon: Icon(Icons.arrow_back),
                      onPressed: null,
                    ),
                  ),
                ],
              ),
            ),
            // -------- HEADER BULAT + CARD SALDO --------
            Stack(
              clipBehavior: Clip.none,
              children: [
                // Background kuning bulat
                Container(
                  width: double.infinity,
                  height: 135,
                  decoration: const BoxDecoration(
                    color: Color(0xFFFFF1C1),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(60),
                      bottomRight: Radius.circular(60),
                    ),
                  ),
                ),
                // Card saldo
                Positioned(
                  top: 48,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: Container(
                      width: MediaQuery.of(context).size.width - (margin * 2),
                      padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFFFE086), Color(0xFFFFBB00)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.yellow.withOpacity(0.18),
                            blurRadius: 22,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Text(
                            "Dana Tabungan",
                            style: TextStyle(
                              color: Colors.white70,
                              fontWeight: FontWeight.w400,
                              fontSize: 15,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            "Rp 56.000,00",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 28,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 6),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              Icon(Icons.show_chart, size: 17, color: Colors.white),
                              SizedBox(width: 4),
                              Text(
                                "Rp 2.867.200 (5,12%)",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 95),
            // -------- FITUR-FITUR & PRODUK CARD --------
            Padding(
              padding: EdgeInsets.symmetric(horizontal: margin),
              child: Container(
                padding: const EdgeInsets.only(top: 8, bottom: 18, left: 12, right: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Top Row: Produk, Filter, Sort, Periode
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "${produkList.length} Produk",
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        Row(
                          children: [
                            // Filter Button
                            ElevatedButton(
                              onPressed: () => _showFilterBottomSheet(context),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFFFD773),
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(horizontal: 18),
                                elevation: 0,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                              ),
                              child: const Text("Filter", style: TextStyle(fontWeight: FontWeight.bold)),
                            ),
                            const SizedBox(width: 8),
                            // Sort Button
                            ElevatedButton(
                              onPressed: () => _showSortBottomSheet(context),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFFFD773),
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(horizontal: 18),
                                elevation: 0,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                              ),
                              child: const Text("Sort", style: TextStyle(fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    // Periode imbal hasil dropdown
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text("Periode imbal hasil", style: TextStyle(fontSize: 15)),
                        GestureDetector(
                          onTap: () => _showPeriodeBottomSheet(context),
                          child: Row(
                            children: [
                              Text(
                                selectedPeriode,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFFFFB700),
                                ),
                              ),
                              const Icon(Icons.keyboard_arrow_down, color: Color(0xFFFFB700)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    // Produk List
                    produkList.isEmpty
                        ? Padding(
                            padding: const EdgeInsets.symmetric(vertical: 24),
                            child: Center(child: Text("Tidak ada produk ditemukan")),
                          )
                        : Column(
                            children: produkList.map((produk) => _produkCard(produk)).toList(),
                          ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  // ----- PRODUK CARD -----
  Widget _produkCard(Map<String, dynamic> produk) {
    // Format angka dan persen
    String imbalStr = "${produk["imbal"].toStringAsFixed(2)}%/th";
    String hargaStr = "Rp${produk["harga"].toStringAsFixed(2)}";
    String kelolaanStr = "Rp${produk["kelolaan"]} T";
    return GestureDetector(
      onTap: () {
        // Navigate ke halaman topup_page.dart
        Navigator.push(context, MaterialPageRoute(builder: (_) => TopUpPage()));
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 7),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: Colors.grey.shade300),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade100,
              blurRadius: 2,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: const Color(0xFFFFD773),
              radius: 26,
              child: produk["logo"] != null
                  ? Image.asset(produk["logo"], width: 30, height: 30)
                  : null,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(produk["name"], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  Text(produk["manager"], style: TextStyle(color: Colors.grey[700], fontSize: 13)),
                  const Divider(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Imbal Hasil", style: TextStyle(fontSize: 12, color: Colors.black54)),
                          Text(imbalStr, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFFFB700))),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Harga/Unit", style: TextStyle(fontSize: 12, color: Colors.black54)),
                          Text(hargaStr, style: const TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Dana Kelolaan", style: TextStyle(fontSize: 12, color: Colors.black54)),
                          Text(kelolaanStr, style: const TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --------- FILTER BOTTOM SHEET ---------
  void _showFilterBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(24, 18, 24, 24),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(height: 5, width: 42, margin: const EdgeInsets.only(bottom: 18), decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(4))),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: const Text("Filter", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _checkbox("Produk Syariah", filterSyariah, (val) => setModalState(() => filterSyariah = val!)),
                      const SizedBox(width: 12),
                      _checkbox("Produk Baru", filterBaru, (val) => setModalState(() => filterBaru = val!)),
                    ],
                  ),
                  Row(
                    children: [
                      _checkbox("Produk Terbatas", filterTerbatas, (val) => setModalState(() => filterTerbatas = val!)),
                      const SizedBox(width: 12),
                      _checkbox("Dividen", filterDividen, (val) => setModalState(() => filterDividen = val!)),
                    ],
                  ),
                  const Divider(thickness: 1.2),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("Autodebet", style: TextStyle(fontSize: 16)),
                      Switch(
                        activeColor: const Color(0xFFFFB700),
                        value: filterAutodebet,
                        onChanged: (val) => setModalState(() => filterAutodebet = val),
                      )
                    ],
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFFFF1CC),
                            foregroundColor: const Color(0xFFFFB700),
                            elevation: 0,
                          ),
                          child: const Text("Reset Filter"),
                          onPressed: () {
                            setModalState(() {
                              filterSyariah = false;
                              filterBaru = false;
                              filterTerbatas = false;
                              filterDividen = false;
                              filterAutodebet = false;
                            });
                          },
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFFFB700),
                            foregroundColor: Colors.white,
                            elevation: 0,
                          ),
                          child: const Text("Tampilkan"),
                          onPressed: () {
                            setState(() {});
                            Navigator.pop(context);
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _checkbox(String label, bool value, ValueChanged<bool?> onChanged) {
    return Expanded(
      child: CheckboxListTile(
        value: value,
        onChanged: onChanged,
        contentPadding: EdgeInsets.zero,
        title: Text(label, style: const TextStyle(fontSize: 14)),
        controlAffinity: ListTileControlAffinity.leading,
        activeColor: const Color(0xFFFFB700),
      ),
    );
  }

  // --------- SORT BOTTOM SHEET ---------
  void _showSortBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(24, 18, 24, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(height: 5, width: 42, margin: const EdgeInsets.only(bottom: 18), decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(4))),
                Align(
                  alignment: Alignment.centerLeft,
                  child: const Text("Sort", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                ),
                const SizedBox(height: 14),
                ...[
                  "Imbal Hasil Tertinggi",
                  "Dana Kelolaan Tertinggi",
                  "Nama A-Z",
                  "Barometer Tertinggi",
                ].map((sort) {
                  return RadioListTile(
                    value: sort,
                    groupValue: selectedSort,
                    activeColor: const Color(0xFFFFB700),
                    onChanged: (val) => setModalState(() => selectedSort = val!),
                    title: Text(sort, style: const TextStyle(fontSize: 14)),
                  );
                }),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFFB700),
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: const Text("Terapkan"),
                    onPressed: () {
                      setState(() {});
                      Navigator.pop(context);
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // --------- PERIODE BOTTOM SHEET ---------
  void _showPeriodeBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(height: 5, width: 42, margin: const EdgeInsets.only(bottom: 18), decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(4))),
            ...["1 Bulan", "6 Bulan", "1 Tahun", "3 Tahun", "5 Tahun"].map((periode) {
              return ListTile(
                tileColor: periode == selectedPeriode ? const Color(0xFFFFF5D6) : null,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
                title: Center(
                  child: Text(
                    periode,
                    style: TextStyle(
                      fontWeight: periode == selectedPeriode ? FontWeight.bold : FontWeight.normal,
                      color: Color(0xFFFFB700),
                    ),
                  ),
                ),
                onTap: () {
                  setState(() => selectedPeriode = periode);
                  Navigator.pop(context);
                },
              );
            }),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFB700),
                  foregroundColor: Colors.white,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text("Pilih"),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
