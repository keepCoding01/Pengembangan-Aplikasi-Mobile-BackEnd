class Modul {
  final String title;
  final String image;
  final String chapter;
  final String? presenter;
  final String? videoUrl;
  final List<String>? learningPoints;
  final List<Modul>? nextChapters;

  Modul({
    required this.title,
    required this.image,
    required this.chapter,
    this.presenter,
    this.learningPoints,
    this.nextChapters,
    this.videoUrl,
  });
}
