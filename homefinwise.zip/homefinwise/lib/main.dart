import 'package:homefinwise/screens/cover_page.dart';

import 'theme_notifier.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; 



void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => ThemeNotifier(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeNotifier>(
      builder: (context, themeNotifier, child) {
        return MaterialApp(
          title: 'FinWise',
          theme: ThemeData(
            fontFamily: 'Inter',
            brightness: Brightness.light,
          ),
          darkTheme: ThemeData(
            fontFamily: 'Inter',
            brightness: Brightness.dark,
          ),
          themeMode: themeNotifier.isDark ? ThemeMode.dark : ThemeMode.light,
          home: const CoverPage(),
          // home: const MainNavigation(),
          debugShowCheckedModeBanner: false,
        );
      },
    );
  }
}
