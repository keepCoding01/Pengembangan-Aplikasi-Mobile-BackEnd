package com.example.homefinwise

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
